#!/usr/bin/perl

$size = 0;
$idx = '';
$dat = '';

while (<>) {
    if (/[wW]\s+2\s+([0-9A-F])\s+([a-zA-Z0-9]*)/) {
	$a = $1;
	$b = $2;
	if ($size != 0) {
	    $idx .= ',';
	    $dat .= ',';
	}
	if (($size % 16)==0) {
	    $idx .= "\n    ";
	} else {
	    $idx .= ' ';
	}
	if (($size % 8)==0) {
	    $dat .= "\n    ";
	} else {
	    $dat .= ' ';
	}
	$size++;
	$idx .= "$a";
	$dat .= "0x$b";
    }
}
print "\n";
print "#if 0\n";
print "void LoadUserCode(void) {\n";
print "  int i;\n";
print "  for (i=0;i<CODE_SIZE;i++) {\n";
print "    WriteVS10xxRegister(atab[i], dtab[i]);\n";
print "  }\n";
print "}\n";
print "#endif\n";
print "\n";
print "#define CODE_SIZE $size\n";
print "const unsigned char atab[CODE_SIZE] = { /* Register addresses */";
print "$idx\n";
print "};\n";
print "const unsigned short dtab[CODE_SIZE] = { /* Data to write */";
print "$dat\n";
print "};\n";

