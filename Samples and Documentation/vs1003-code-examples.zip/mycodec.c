/*
  Example application to be loaded after VS1003 bootup.
  Activation by
 */


#include <string.h>

#define STANDALONE

#include "vs1003.h"
#include <h1003/asmfuncs.h>

#include <stdio.h>
#include <stdlib.h>

extern __y s_int32 moduOffset;
extern __y u_int16 intClock2KHz, clockX, clockA;

s_int16 adcData;
s_int16 adcMax;

/* ADC interrupt handler.
   Do not spend more time here than necessary or the maximum SDI transfer
   speed will decrease. */
void ADCInt(void) {
    /* ADC offset removal (slow highpass) */
    register s_int16 out = USEX(MODU_DATA) - (moduOffset>>16);
    moduOffset += out;
    adcData = out;

    if (adcMax <= out) {
	adcMax = out;
    } else {
	adcMax = ((s_int32)adcMax * 65500U) >> 16;
    }
}

#define TIMEBASE /* generate a timebase not dependent on sample rate */
#ifdef TIMEBASE
/* one way to implement timebase */
u_int16 sampCount;
u_int16 timeCount;
#endif /*TIMEBASE*/

s_int16 ApplAddr(register __i0 s_int16 **d, register __a1 s_int16 mode,
		 register __a0 s_int16 n) {
    if (mode == APPL_AUDIO) {
#ifdef TIMEBASE
	register u_int16 t = hwSampleRate / 16;
	sampCount += n;
	if (sampCount >= t) {
	    sampCount -= t;
	    timeCount++;
	}
#endif /*TIMEBASE*/
#if 0
	{
	    register s_int16 i;
	    register s_int16 *s = *d;
	    for (i=0;i<n;i++) {
		*s = adcData; /* replace left-channel data */
		s += 2;
	    }
	}
#endif

#if 0 /* a poor-man's 'pitch-shifter' for testing purposes */
	if (adcMax > 0x400) {
	    return n/2; /* only return half of the samples */
	}
#endif
    }
    return n;
}


/*
  Called before HALT, i.e. when there is nothing else to do.

  Either there is not enough data in stream buffer to perform decoding
  and the decoder has to wait for data, or the audio buffer is full and
  the decoder has to wait for some audio data to be played.
 */
void UserHook(void) {
    /* Note: more filtering and hysteresis should be added to volume change. */
    u_int16 newVol = USEX(SCI_VOL);
    if (adcMax > 0x800) {
	newVol = 0x0000;
    } else if (adcMax > 0x400) {
	newVol = 0x0606;
    } else if (adcMax > 0x200) {
	newVol = 0x0c0c;
    } else if (adcMax > 0x100) {
	newVol = 0x1212;
    }
    if (newVol != USEX(SCI_VOL)) {
	/* Don't call SetVolumeFromSpi() if the volume hasn't changed. */
	USEX(SCI_VOL) = newVol;
	SetVolumeFromSpi();
    }
}


/*
  This routine is called through a stub function (in c.s) when
  0x30 is written to SCI_AIADDR.
 */
s_int16 mycodec(register __i0 s_int16 **d, register __a1 s_int16 mode,
		register __a0 s_int16 n) {
    /* zero applAddr so we are not called again */
    applAddr = 0;

#if 0
    USEX(SCI_CLOCKF) = 0x8000; /* 3.0x 12.288MHz */
    SetClockFromSpi();
#endif

#if 1
    /* Install a user codec for audio output */
    applAddr = ApplAddr;
#endif
#if 1
    /* Install a hook that is called whenever we have free CPU */
    {
	register u_int32 t = ReadFromProgramRam(0x32); /* j _UserHook */
	WriteToProgramRam(0, t>>16, t);
    }
#endif
#if 1
    /* Install an ADC interrupt routine (stub in c.s which calls ADCInt()) */
    {
	register u_int32 t = ReadFromProgramRam(0x33);
	WriteToProgramRam(0x23, t>>16, t);
    }
    /* ADC frequency:
       Fs = CLKI / 128 / MODU_DIV
       MODU_DIV = CLKI / 128 / Fs
    */
#if 0
    /* For this to work you need to write SCI_CLOCKF before SCI_AIADDR and
       not change SCI_CLOCKF afterwards. */
    USEX(MODU_DIV) = (u_int32)intClock2KHz * 2000 / (128L * 8000);
#else
    /* If the actual sample rate does not matter so much, just use a fixed
       divider, or calculate the value at compile time. */
    USEX(MODU_DIV) = (12288000/(128 * 8000));
    USEX(MODU_DIV) = 24;
#endif
    USEX(INT_ENABLE) |= (1<<INT_EN_MODU);
#endif
    return 0;
}
