#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char dd[256];
char ss[256];
char __y dy[256];

void Void(void) {

}


void MemCpy0(char *d, const char *s, int n) {
    int i;
    for (i=0; i<n; i++)
	d[i] = s[i];
}

void MemCpy1(char *d, const char *s, int n) {
    int i;
    for (i=0; i<n; i++)
	*d++ = *s++;
}

void MemCpy2(char *d, const char *s, int n) {
    register int i;
    for (i=0; i<n; i++)
	*d++ = *s++;
}

void MemCpy3(char *d, const char *s, int n) {
    register int i;
    register char *D = d;
    register const char *S = s;
    for (i=0; i<n; i++)
	*D++ = *S++;
}

void MemCpy4(char __y *d, const char *s, int n) {
    register int i;
    register char __y *D = d;
    register const char *S = s;
    for (i=0; i<n; i++)
	*D++ = *S++;
}

void MemCpy5(register __i0 char __y *d, register __i1 const char *s, register __a0 int n) {
    register int i;

    /* If n is not divisible by 8, copy modulo amount */
    for (i=0; i<(n&7); i++)
	*d++ = *s++;

    /* Divide n by 8, because 8 words are copied in one loop */
    n /= 8;

    /* A loop unrolled by a factor of 8 */
    for (i=0; i<n; i++) {
	*d++ = *s++;	*d++ = *s++;
	*d++ = *s++;	*d++ = *s++;
	*d++ = *s++;	*d++ = *s++;
	*d++ = *s++;	*d++ = *s++;
    }
}


void StrCpy0(char *d, const char *s) {
    while (*s)
	*d++ = *s++;
    *d = *s;
}

void StrCpy1(char *d, const char *s) {
    while ((*d++ = *s++))
	;
}

void StrCpy2(register __i0 char *d, const register __i1 char *s) {
    while ((*d++ = *s++))
	;
}

void StrCpy3(register __i0 __y char *d, const register __i1 char *s) {
    while ((*d++ = *s++))
	;
}

int FIR(register __i0 __y int *s1, register __i2 int *s2,
	register __a0 int len) {
    register __a1 int i;
    register __b long res = 0;

    len /= 8;
/*    res >>= 24;*/

    for (i=0; i<len; i++) {
	res += *s1++ * *s2++;   res += *s1++ * *s2++;
	res += *s1++ * *s2++;   res += *s1++ * *s2++;
	res += *s1++ * *s2++;   res += *s1++ * *s2++;
	res += *s1++ * *s2++;   res += *s1++ * *s2++;
    }

    return (int)((res << 3) >> 16);
}

int AsmFIR(register __i0 __y int *s1, register __i2 int *s2,
	   register __a0 int len);



int main(void) {
    int i;

    for (i=0; i<255; i++)
	ss[i] = i+1;
    ss[255] = 0;

    MemCpy0(dd, ss, 256);
    MemCpy1(dd, ss, 256);
    MemCpy2(dd, ss, 256);
    MemCpy3(dd, ss, 256);
    MemCpy4(dy, ss, 256);
    MemCpy5(dy, ss, 256);
    StrCpy0(dd, ss);
    StrCpy1(dd, ss);
    StrCpy2(dd, ss);
    StrCpy3(dy, ss);

    /* We check that we get the same results from our C and assembler FIR
       filters */
    printf("  C: %d\n",    FIR((int __y *)dy, (int *)ss, 256));
    printf("Asm: %d\n", AsmFIR((int __y *)dy, (int *)ss, 256));
#if 0
    /* The following is a pointer reference to address 0xFFFF, which causes
       the simulator to stop with an error message unless address 0xFFFF is
       defined as a valid address in mem_config. */
    *((volatile unsigned int *)(0xFFFFU));    
#endif
    return 0;
}
