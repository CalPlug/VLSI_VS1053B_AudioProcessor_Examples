#include <stdio.h>

#define TABSIZE 4096


/* Checks if the given bit is set in an integer table */
static unsigned int BitIsSet(register unsigned int __y *t,
			     register unsigned int bit) {
    return t[bit >> 4] & (32768U >> (bit&0xf));
}

/* Sets a given bit to 1 in an integer table */
void SetBit(register unsigned int __y *t, register unsigned int bit) {
    t[bit>>4] |= (32768U >> (bit&0xf));
}

/* This program searches for prime numbers using Aristothele's comb */
int main(void) {
    static unsigned int __y tab[(TABSIZE+15)>>4]; /* Depends on 16-bit ints */
    register unsigned int i, j;

    puts("VSDSP demonstration program: Searching for prime numbers");

    /* The following scope is created for the temporary pointer t */
    {
	register unsigned int __y *t = tab;

	for (i=0; i<(TABSIZE+15)>>4; i++)
	    *t++ = 0;
    }

    for (i=2; i<TABSIZE; i++) {
	if (!BitIsSet(tab, i)) {
	    printf("%d\n", i);
	    for (j=i; j<TABSIZE; j+=i)
		SetBit(tab, j);
	}
    }

    /* The following is a pointer reference to address 0xFFFF, which causes
       the simulator to stop with an error message unless address 0xFFFF is
       defined as a valid address in mem_config. */
    *((volatile unsigned int *)(0xFFFFU));

    return 0;
}
