This is a distribution of VLSI Solution Oy's VS_DSP software tools.
This free version does not support 32-bit code or data addressing
nor C-level debug information.

This package contains the following directories:

bin:
	Contains the executable versions of the software tools.

	[1]
	The provided make.exe is distributed under the GNU license, the
	source code is available at http://www.vlsi.fi/software/make-3791.zip
	or directly from ftp://ftp.gnu.org/gnu/make/make-3.79.1.tar.gz
	This only applies to the Windows distribution.

config:
	Contains example configuration files for the software tools.

pdf:
	Contains hardware and software documentation in Acrobat Reader PDF
	format.

src:
	Contains test software source code that is mentioned in the
	software tools documentation.

libc16:
	Contains 16-bit code (-fsmall-code) libraries.

libc16_v3:
	Contains 16-bit code (-fsmall-code) libraries for core version 3.

For information about installing the tools, read file "UNPACK.txt".

All programs (except[1]) are Copyright 1995-2003 VLSI Solution Oy
(http://www.vlsi.fi/) and may not be redistributed without permission.
