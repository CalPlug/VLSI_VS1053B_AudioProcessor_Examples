#ifndef CTYPE_H
#define CTYPE_H

int register __a0 isalnum(int register __i0 c);
int register __a0 isalpha(int register __i0 c);
int register __a0 iscntrl(int register __i0 c);
int register __a0 isdigit(int register __i0 c);
int register __a0 isgraph(int register __i0 c);
int register __a0 islower(int register __i0 c);
int register __a0 isprint(int register __i0 c);
int register __a0 ispunct(int register __i0 c);
int register __a0 isspace(int register __i0 c);
int register __a0 isupper(int register __i0 c);
int register __a0 isxdigit(int register __i0 c);
int register __i0 tolower(int register __i0 c);
int register __i0 toupper(int register __i0 c);

#endif /* CTYPE_H */
