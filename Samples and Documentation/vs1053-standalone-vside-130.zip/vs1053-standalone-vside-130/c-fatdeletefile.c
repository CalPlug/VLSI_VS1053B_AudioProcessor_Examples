#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fat.h"
#include "standalone.h"

#define DEBUG_LEVEL 0

/* Note: does not delete long file entries that point to this entry!! */
void FsDeleteFile(void) {
    /*Assumes: fatInfo.dirSector, fatInfo.dirLine, fragments[] */
#if 0
    if (fatInfo.dirLine < 0)
	return;
#endif
    /* Delete file from directory */
    ReadDiskSectorTo(fatInfo.currentSector = fatInfo.dirSector, stream_buffer);
    stream_buffer[fatInfo.dirLine/2] =
	(stream_buffer[fatInfo.dirLine/2] & 0x00ff) | 0xe500;
    MmcWrite(fatInfo.currentSector, stream_buffer);
    /* Note: does not delete long filename entries! */

    /* deallocate sectors, but be careful -
       there won't be a valid chain to free if the file size is 0 */
    if (fatInfo.totSize) {
	register __mem_y struct FRAGMENT *frag = fragments-1;
	do {
	    frag++;
#if 0
putch('f');
putch(' ');
puthex(frag->size);
putch('\n');
#endif
	    FsFatAllocate2(frag->start & 0x7fffffffUL,
			   frag->size,
			   0x0fffffffUL, 1/*1=Free*/);
	} while ((s_int32)frag->start >= 0);
    }
}
