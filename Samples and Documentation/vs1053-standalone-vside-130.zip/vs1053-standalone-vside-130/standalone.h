#ifndef STANDALONE_H
#define STANDALONE_H
#define STANDALONE  /*defined for vs1053 header files*/

/* Now supports High-Capacity SD (SDHC) cards by default!
   20150930 Now always supports subdirectories.
   20151001 Now always keeps drivers off until SD card found.
   20151021 Supports UART,buttons and SCI at the same time.
            Recorder can be started multiple ways, and name given in filemode.
	    Delete command in recorder. (Does not remove long filenames.)
	    SCI_UI now always on, define removed.
   20151022 Disabled pause mode from PatchStereoCopy (not needed).
   20161005 Continued improving the UART control.
*/

#define UART_BUFFERED /* Use buffered UART commands. Currenly required! */
//#define SCI_KEYS /* Both SCI control and keys (GPIO4 through GPIO6). */
#define COMPAT_KEYS  /**< Read the old 3-button interface of vs10xx prototyping board. (is overriden by SCI_KEYS) */
//#define DIRECT_KEYS /**< Read directly connected keys. (is overriden by COMPAT_KEYS) */

#define USE_PRINTABLE_OUTPUT /* Use decimal printable output instead of raw/hex. */

//#define RESTORE_POSITION

/*Note: FLAC uses XY 0x2000..0x3fff (flacData), Y 0x1000..0x1fff (flacSave).
        FLAC also increases the stream buffer size from 0x400 to 0x1800. */
//#define USE_FLAC /**< Enable FLAC decoding. Note: FLAC is not available in the recorder. It is also not available with UART_BUFFERED. */
#define AAC_PATCH /**< Include 2 patches for AAC */

#define SHUFFLE_PLAY /**< shuffle play instead of random */
#define SKIP_ID3V2   /**< quickly skip ID3v2 tags */

//#define NO_WMA /**< reject WMA files */
//#define NO_AAC /**< reject AAC files */
//#define NO_MIDI /**< reject MIDI files */

//#define TIMEOUT /**< timeout when decoding seems to be stuck */
#define HDATCHECK 800 /**< give up after 800/2=400kB ~ 3-6sec */
//#define ENABLE_I2S /**< Enable I2S output*/
#define ENABLE_HIGHREF /**< Use 1.6V reference voltage -- use if AVDD >= 3.3V*/

/** Note: saving settings requires that the SCI register data section is first
    in the executable for the SPI boot image to also contain it at the beginning
    at a fixed location. Currently this is only arranged for the command-line
    version compiled with the make tool.

    ** THIS does not work with the VSIDE solution. **
*/
//#define SAVE_OFFSET 0 /**< start of SCI registers in the boot image */
//#define SAVE_VOLUME /**< Save volume setting to EEPROM */
//#define SAVE_POSITION /**< Save playing song to EEPROM */

//#define PAUSE_AT_POWERON /* if PAUSE_BEFORE_PLAY at poweron, pause before the first file and change mode to PAUSE_AFTER_PLAY. */

//#define USE_REWIND /*long press of prev/vol- rewinds instead of volume down*/
//#define LOOP_FILES     /* play the same file until file changed - uses CTRL3_LOOP_SONG */

#define RECORD_FS 24000 /* The default recording samplerate. */

//#define SD_POWER_ENABLE (1<<6) /* GPIO6 used for SD power enable */
#define SD_POWER_ENABLE 0 /* Not used */

/*
  Definitions for AICTRL3
 */
//#define CTRL3_UPDATE_VOL        (1<<15) /*not needed for vs1053*/
#define CTRL3_ITERATE           (1<<14)
#define CTRL3_BY_NAME           (1<<8) /*locate by name*/
#define CTRL3_RECORD_ON         (1<<7)
#define CTRL3_AT_END            (1<<6)
#define CTRL3_NO_NUMFILES       (1<<5)
#define CTRL3_PAUSE_ON          (1<<4)
#define CTRL3_FILE_READY        (1<<3)

#define CTRL3_PLAY_MODE_MASK    (3<<1)
#define CTRL3_PAUSE_AFTER_PLAY  (3<<1)
#define CTRL3_PAUSE_BEFORE_PLAY (2<<1)
#define CTRL3_LOOP_SONG         (1<<1)
#define CTRL3_PLAY_NEXT         (0<<1)

#define CTRL3_RANDOM_PLAY       (1<<0) /* SCI_AICTRL3 */


/*
  MMC/SD command list
 */
#define MMC_GO_IDLE_STATE   0
#define MMC_SEND_OP_COND   1
#define MMC_SEND_IF_COND   8
#define MMC_SEND_CSD   9
#define MMC_SEND_CID   10
#define MMC_STOP_TRANSMISSION   12
#define MMC_SEND_STATUS   13
#define MMC_SET_BLOCKLEN   16
#define MMC_READ_SINGLE_BLOCK   17
#define MMC_READ_MULTIPLE_BLOCK   18
#define MMC_WRITE_BLOCK   24
#define MMC_PROGRAM_CSD   27
#define MMC_SET_WRITE_PROT   28
#define MMC_CLR_WRITE_PROT   29
#define MMC_SEND_WRITE_PROT   30
#define MMC_TAG_SECTOR_START   32
#define MMC_TAG_SECTOR_END   33
#define MMC_UNTAG_SECTOR   34
#define MMC_TAG_ERASE_GROUP_START   35
#define MMC_TAG_ERARE_GROUP_END   36
#define MMC_UNTAG_ERASE_GROUP   37
#define MMC_ERASE   38
#define MMC_READ_OCR     58
#define MMC_CRC_ON_OFF   59
#define MMC_R1_BUSY   0x80
#define MMC_R1_PARAMETER   0x40
#define MMC_R1_ADDRESS   0x20
#define MMC_R1_ERASE_SEQ   0x10
#define MMC_R1_COM_CRC   0x08
#define MMC_R1_ILLEGAL_COM   0x04
#define MMC_R1_ERASE_RESET   0x02
#define MMC_R1_IDLE_STATE   0x01
#define MMC_STARTBLOCK_READ   0xFE
#define MMC_STARTBLOCK_WRITE   0xFE
#define MMC_STARTBLOCK_MWRITE   0xFC
#define MMC_STOPTRAN_WRITE   0xFD
#define MMC_DE_MASK   0x1F
#define MMC_DE_ERROR   0x01
#define MMC_DE_CC_ERROR   0x02
#define MMC_DE_ECC_FAIL   0x04
#define MMC_DE_OUT_OF_RANGE   0x04
#define MMC_DE_CARD_LOCKED   0x04
#define MMC_DR_MASK   0x1F
#define MMC_DR_ACCEPT   0x05
#define MMC_DR_REJECT_CRC   0x0B
#define MMC_DR_REJECT_WRITE_ERROR   0x0D


#ifdef ASM
/* asm-only definitions here */


#else/*ASM*/
/* C-only definitions here */

#include <h1053/vsmpg.h>
#include <h1053/hardware.h>
#include <h1053/common.h>
#include <h1053/asmfuncs.h>
#include <h1053/parametric.h>
#include <vstypes.h>

/* Low-level UART output functions. */
void putch(register __a0 int ch);
void putword(register __a0 int ch);

void putstrp(register __i2 u_int16 *p);
void putstrpy(register __i2 __mem_y u_int16 *p);
void putdec(register __reg_b u_int32 a);
void puthex(register __c0 u_int16 d);

void BusyWait10(void);

void SpiLoad(register __i2 short startAddr);

auto s_int16 myrand(void); /* output 0..0x3fff */
extern __mem_y s_int16 rand_seed;

#include "fat.h"

void SpiLoadStub(register __i2 short start, register __a0 short a24);

void MyReset();

auto void SpiSendClocks(void);
auto u_int16 SpiSendReceiveMmc(register __a0 u_int16 topAlignedData,
			       register __a1 numBits);
auto u_int16 MmcCommand(register __b0 s_int16 cmd, register __d u_int32 arg);
s_int16 InitializeMmc(s_int16 tries);
s_int16 InitializeMmcRecorder(s_int16 tries);
auto void ReadDiskSectorTo(register __reg_a u_int32 sector, register __i2 u_int16 *buffer);
auto void WritePhysicalSectorY(register __d u_int32 address,
			      register __i3 __mem_y u_int16 *dataBufPtr);
auto s_int16 WritePhysicalSectorYSwap(register __d u_int32 address,
			      register __i3 __mem_y u_int16 *dataBufPtr);

/* FAT filesystem-related */
auto u_int16 GetByte(register __c0 u_int16 n);
auto u_int16 GetWord(register __c0 u_int16 n);
auto u_int32 GetLong(register __c0 u_int16 n);
auto u_int16 swap(register __a0 u_int16 val);


extern __mem_y u_int16 fileName[6];
#ifdef FATINFO_IN_Y
extern __mem_y struct FATINFO fatInfo;
#else
extern struct FATINFO fatInfo;
#endif
auto u_int16 InitFileSystem(void);
auto u_int16 InitFileSystemR(void);
auto __mem_y struct FRAGMENT *FragmentList(register __i2 __mem_y struct FRAGMENT *frag,
			  register __reg_b u_int32 fatCluster);
auto s_int16 HandleDir(register __i2 __mem_y struct FRAGMENT *curFragment,
		       __mem_y struct FRAGMENT *nextFragment);
auto s_int16 OpenFile(register __c0 u_int16 fileNum);
void FsDeleteFile(void);
auto s_int16 CheckFileType(register __reg_a u_int32 name);
auto s_int16 CheckFileType1053(register __reg_a u_int32 name);
void IterateFilesCallback(register __b0 u_int16 *name);

extern u_int16 created[3]; /*create date, time, 100ths */

int UartFill(void);
int UartGetByte(void);
int UartPeekByte(void);
auto u_int32 NextSector(void);

u_int16 Shuffle(register __c0 u_int16 files, register __c1 u_int16 old);

#endif/*elseASM*/

#endif/*STANDALONE_H*/
