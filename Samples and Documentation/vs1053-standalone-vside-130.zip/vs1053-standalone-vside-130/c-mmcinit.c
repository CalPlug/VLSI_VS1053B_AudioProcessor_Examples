#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "standalone.h"


#if 0
void BusyWait10() {
    int i;
    for (i=0;i<30000;i++)
	USEX(0);
}
#endif

s_int16 InitializeMmc(s_int16 tries) {
    register s_int16 i, cmd;
    mmc.state = mmcNA;
    mmc.blocks = 0;
    mmc.errors = 0;

 tryagain:
#if defined(SD_POWER_ENABLE) && SD_POWER_ENABLE
    /* If required, power down MMC/SD to make it leave SD mode.
       However, it should not be powered down at each tryagain,
       because sometimes multiple passes are required to bring
       the card into operating mode. */
    // MMC reset using SD_POWER_ENABLE
    USEX(GPIO_DDR) |= SD_POWER_ENABLE;
    USEX(SER_DREQ) = 0;
    {
	u_int16 gpio0_save = USEX(GPIO_ODATA);
	USEX(GPIO_ODATA) = 1; //all 0 except eecs
	for (i=0; i<32000; i++) {
	    USEX(GPIO_ODATA) = 1; //all 0 except eecs
	}
	USEX(GPIO_ODATA) = gpio0_save | SD_POWER_ENABLE;
    }
#endif

    //UserHook();//IdleHook();
    mmc.hcShift = 9;
    if (tries-- <= 0) {
        return ++mmc.errors;
    }
    for (i=0; i<512; i++) {
        SpiSendClocks();
    }

    /* MMC Init, command 0x40 should return 0x01 if all is ok. */
    i = MmcCommand(MMC_GO_IDLE_STATE/*CMD0*/|0x40,0);
    if (i != 1) {
        BusyWait10();
        goto tryagain;//continue; /* No valid idle response */
    }
//putstrp("\pGO_IDLE_STATE ok\n");
    cmd = MMC_SEND_OP_COND|0x40;
    /*CMD8 is mandatory before ACMD41 for hosts compliant to phys. spec. 2.00*/
    i = MmcCommand(MMC_SEND_IF_COND/*CMD8*/|0x40,
                   0x00000122/*2.7-3.6V*/); /*note: 0x22 for the right CRC!*/
#if DEBUG_LEVEL > 2
    puthex(i);
    puts("=IF_COND");
#endif
    if (i == 1) {
        /* MMC answers: 0x05 illegal command, v2.0 SD(HC-SD) answers: 0x01 */
        /* Should we read the whole R7 response? */
#if DEBUG_LEVEL > 1
        //SpiSendReceiveMmc(-1, 32);
        puthex(SpiSendReceiveMmc(-1, 16));
        puthex(SpiSendReceiveMmc(-1, 16));
        puts("=R7");
#else
        SpiSendReceiveMmc(-1, 32); /*read the whole response*/
#endif
        cmd = 0x40|41; /* ACMD41 - SD_SEND_OP_COND */
    }

#if 0
    do {
        i = MmcCommand(MMC_READ_OCR/*CMD58*/|0x40, 0);
#if DEBUG_LEVEL > 1
        puthex(i);
        puthex(SpiSendReceiveMmc(-1, 16));
        puthex(SpiSendReceiveMmc(-1, 16));
        puts("=READ_OCR");
#endif
    } while (0);
#else
    /* Some cards require CMD58 after CMD8 -- does this still work with MMC?*/
    MmcCommand(MMC_READ_OCR/*CMD58*/|0x40, 0);
    SpiSendReceiveMmc(-1, 16);
    SpiSendReceiveMmc(-1, 16);
#endif

    /* MMC Wake-up call, set to Not Idle (mmc returns 0x00)*/
    i = 0; /* i is 1 when entered .. but does not make the code shorter*/
    while (1) {
        register int c;
        if (cmd == (0x40|41)) {
            c = MmcCommand(0x40|55/*CMD55*/,0);
#if DEBUG_LEVEL > 2
            puthex(c);
            puts("=CMD55");
#endif
        }
        c = MmcCommand(cmd/*MMC_SEND_OP_COND|0x40*/,
                       /* Support HC for SD, AND for MMC! */
                       //i ? 0x40100000UL : 0x00000000UL
                       0x40100000UL);

#if DEBUG_LEVEL > 1
        puthex(c);
        puts("=ACMD41");
#endif

        if (c == 0) {
#if DEBUG_LEVEL > 1
            puts("got 0");
#endif
            break;
        }
        BusyWait10();
        if (++i >= 25000 /*Large value (12000) required for MicroSD*/
            || c != 1) {
#if DEBUG_LEVEL > 1
            puthex(c);
            puts(" Timeout 2");
#endif
            goto tryagain; /* Not able to power up mmc */
        }
    }
    i = MmcCommand(MMC_READ_OCR/*CMD58*/|0x40, 0);
#if DEBUG_LEVEL > 1
    puthex(i);
    puts("=READ_OCR");
#endif
    if (//cmd == (0x40|41) &&
        i == 0) {
        if (SpiSendReceiveMmc(-1, 16) & (1<<(30-16))) {
            /* OCR[30]:CCS - card capacity select */
            /* HighCapacity! */
#if DEBUG_LEVEL > 1
            puts("=HC");
#endif
            mmc.hcShift = 0;
        }
        /*read all of the OCR data to make some cards happy */
        SpiSendReceiveMmc(-1, 16);
    }

#if 0
    if (MmcCommand(MMC_SEND_CID/*CMD10*/|0x40, 0) == 0) {
	register s_int16 *p = stream_buffer;
	register int t = 3200;
	while (SpiSendReceiveMmc(0xff00, 8) == 0xff) {
	    if (t-- == 0) {
		goto tryagain;
	    }
	}
	for (i=0; i<8; i++) {
	    *p++ = SpiSendReceiveMmc(-1, 16);
	    /*
		       Man     Productname   serial#   date
		          App             rev        res    crc7+stop
		  4G:  1D 4144 0000000000 00 0000157A 0 06A E3
		  64M: 02 0000 53444D3036 34 40185439 0 C77 75
		       00 0011 1122223333 44 44555566 6 677 77

		  2G:  02 544D 5341303247 03 9C046901 0 08B 3D Kingston SD
		  1G:  1B 534D 3030303030 10 B1FFC22A 0 08A 59 Extrememory SD
	    */
	}
	if (!memcpyYX(&stream_buffer[1], &mmc.cid[1], 7)) {
	    /* same card -- use cached information */
	} else {
	    /* different card -- clear all cached values */
	    //memsetY(&mmc, 0, sizeof(mmc)); /*DO NOT clear hcShift etc.!*/
	    memsetY(&mmc.fileName, 0, &mmc.cid[0]-&mmc.fileName[0]);
	    memcpyXY(&mmc.cid, stream_buffer, 8);
#ifdef USE_DEBUG
	    puthex(stream_buffer[0]);
	    puthex(stream_buffer[1]);
	    puthex(stream_buffer[2]);
	    puthex(stream_buffer[3]);
	    puthex(stream_buffer[4]);
	    puthex(stream_buffer[5]);
	    puthex(stream_buffer[6]);
	    puthex(stream_buffer[7]);
	    putch(' ');
	    putch('C');
	    putch('H');
	    putch('G');
	    putch('!');
	    putch(' ');
#endif
	}
//puts("=CID");
    }
#endif


#if 0
    /* Set Block Size of 512 bytes -- default for at least HC */
    /* Needed by MaxNova S043618ATA 2J310700 MV016Q-MMC */
    /* Must check return value! (MicroSD restart!) */
    {
        register int c;
        if ((c = MmcCommand(MMC_SET_BLOCKLEN|0x40, 512)) != 0) {
#if DEBUG_LEVEL > 1
            puthex(c);
            puts(" SetBlockLen failed");
#endif
            goto tryagain;
        }
    }
#endif
    /* All OK return */
    //mmc.errors = 0;
    mmc.state = mmcOk;
//putstrp("\pMMC ok\n");
    return 0;//mmc.errors;
}
