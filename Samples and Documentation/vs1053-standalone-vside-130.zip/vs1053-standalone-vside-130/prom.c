/*

FILE: prom.c - SPI boot programmer
DESCRIPTION: 

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STANDALONE
#include "h1053/hardware.h"

#undef puts
#undef putchar

void putch(register __a0 short ch);

void Halt();
__near void vs3emubreak(register __i1 bp);


typedef long s_int32;
typedef short s_int16;
typedef unsigned short u_int16;
typedef unsigned long u_int32;
typedef __fract short f_int16;
typedef __fract long f_int32;

#define USE_FLASH
#ifdef USE_FLASH
int largeAddr = 1;
#else
int largeAddr = 1;
#endif

static char hex[] = "0123456789abcdef";
void puthex(unsigned int a) {
    char tmp[5];
    tmp[0] = hex[(a>>12)&15];
    tmp[1] = hex[(a>>8)&15];
    tmp[2] = hex[(a>>4)&15];
    tmp[3] = hex[(a>>0)&15];
    tmp[4] = '\0';
    fputs(tmp, stdout);
}

//#define USEY(x) *((__y volatile unsigned short *)(unsigned short)(x))
#ifndef GPIO_IDATA
#define GPIO_IDATA GPIO_DATA
#endif

#define SPI_xCS   1 /* GPIO */
#define SPI_CLK   2
#define SPI_MISO  4
#define SPI_xCS2  8
#define SPI_MOSI  1 /* DREQ */

#define SPI_WREN  0x06
#define SPI_WRDI  0x04
#define SPI_RDSR  0x05
#define SPI_WRSR  0x01
#define SPI_READ  0x03
#define SPI_WRITE 0x02

#define SPI_EEPROM_COMMAND_WRITE_ENABLE  0x06
#define SPI_EEPROM_COMMAND_WRITE_DISABLE  0x04
#define SPI_EEPROM_COMMAND_READ_STATUS_REGISTER  0x05
#define SPI_EEPROM_COMMAND_WRITE_STATUS_REGISTER  0x01
#define SPI_EEPROM_COMMAND_READ  0x03
#define SPI_EEPROM_COMMAND_WRITE 0x02
#define SPI_EEPROM_COMMAND_CLEAR_ERROR_FLAGS 0x30
#define SPI_EEPROM_COMMAND_ERASE_SECTOR 0xD8
#define SPI_EEPROM_COMMAND_ERASE_4K_SECTOR 0x20


auto void SpiPrivDelay(void) {
    int i;
    for (i=0;i<10;i++) {
	USEX(SER_DREQ);
    }
}
auto u_int16 SpiPrivSendReceive(register __a0 u_int16 dat,
			    register __a1 s_int16 bits) {
    register u_int16 odata = 0;
    while (bits--) {
	USEX(SER_DREQ) = (dat>>bits); //bits has been decremented here
	SpiPrivDelay();
	USEX(GPIO_ODATA) |= SPI_CLK;
	SpiPrivDelay();
	odata <<= 1;
#if SPI_MISO == 4
	odata |= (USEX(GPIO_IDATA) >> 2) & 1;
#else
	odata |= (USEX(GPIO_IDATA) & SPI_MISO) ? 1 : 0;
#endif
	USEX(GPIO_ODATA) &= ~SPI_CLK;
    }
    return odata;
}


void SpiPrivInit(void) {
    USEX(GPIO_ODATA) = SPI_xCS|SPI_xCS2;
    USEX(GPIO_DDR)   = SPI_xCS|SPI_CLK|SPI_xCS2;
    USEX(GPIO_ODATA) = SPI_xCS|SPI_xCS2;
}

void SingleCycleCommand(u_int16 cmd){
    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(cmd, 8);
    USEX(GPIO_ODATA) |= SPI_xCS;
}


u_int16 SpiPrivRead(u_int16 addr) {
    u_int16 dat;

    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_READ, 8);
    SpiPrivDelay();
    if (largeAddr) {
	SpiPrivSendReceive(0, 8); //24-bit address
    }
    SpiPrivSendReceive(addr, 16);
    SpiPrivDelay();
    dat = SpiPrivSendReceive(0, 16);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
    return dat;
}

u_int16 SpiPrivStatus(void) {
    u_int16 dat;

    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_RDSR, 8);
    dat = SpiPrivSendReceive(0, 8);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
    return dat;
}

u_int16 SpiPrivWrite(u_int16 addr, u_int16 wrdat) {
    u_int16 dat;

    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_WREN, 8);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;

    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivDelay();
    SpiPrivSendReceive(SPI_WRITE, 8);
    SpiPrivDelay();
    if (largeAddr) {
	SpiPrivSendReceive(0, 8); //24-bit address
    }
    SpiPrivSendReceive(addr, 16);
    SpiPrivDelay();
    dat = SpiPrivSendReceive(wrdat, 16);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
    return dat;
}

void SpiWaitStatus(void) {
    while (SpiPrivStatus() & 1)
	SpiPrivDelay();
}


u_int16 SpiID(void) {
    register u_int16 dat;
    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(0x90, 8);
    SpiPrivSendReceive(0, 8);
    SpiPrivSendReceive(0, 16);
    dat = SpiPrivSendReceive(0, 16);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
#if 1
    puthex(dat);
    puts("=ID");
#endif
    return dat;
}


#if 0
/// Erase one erasable block
/// Erase size for intel flash: 64K (128 disk sectors)
void SpiEraseBlock(u_int32 addr){
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);  

  USEX(GPIO_ODATA) |= SPI_xCS;
  SpiPrivDelay();
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_WRITE_STATUS_REGISTER,8);
  SpiPrivSendReceive(0x02,8); //Sector Protections Off
  USEX(GPIO_ODATA) |= SPI_xCS;
  SpiWaitStatus();
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);  
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_ERASE_SECTOR,8);
  if (largeAddr) {
      SpiPrivSendReceive(addr>>16,8);
  }
  SpiPrivSendReceive(addr,16);
  USEX(GPIO_ODATA) |= SPI_xCS;
  SpiWaitStatus();
}
#endif

#if 1
void EeUnprotect(){
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_WRITE_STATUS_REGISTER,8);
  SpiPrivSendReceive(0x02,8); //Sector Protections Off
  USEX(GPIO_ODATA) |= SPI_xCS;
  SpiWaitStatus();
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
}

void Erase4kBlock(u_int32 addr) {
    // Erase 4K sector
    SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
    SingleCycleCommand(SPI_EEPROM_COMMAND_CLEAR_ERROR_FLAGS);
    EeUnprotect();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_EEPROM_COMMAND_ERASE_4K_SECTOR, 8);
    if (largeAddr) {
	SpiPrivSendReceive(addr>>16,8);
    }
    SpiPrivSendReceive(addr,16);
    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiWaitStatus();
}

#endif

#if 0
u_int16 SpiReadBlock(u_int16 blockn, u_int16 *dptr) {
  SpiWaitStatus();
  
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_READ,8);
  SpiPrivSendReceive(blockn>>7,8);            // Address[23:16] = blockn[14:7]
  SpiPrivSendReceive((blockn<<1),8);     // Address[15:8]  = blockn[6:0]0
  SpiPrivSendReceive(0x00,8);                    // Address[7:0]   = 00000000
  {
    int n;
    for (n=0; n<256; n++){
      *dptr++ = SpiPrivSendReceive(0,16);
    }
  }
  USEX(GPIO_ODATA) |= SPI_xCS;
  return 0;
}
#endif

#if 0
u_int16 SpiVerifyBlock(u_int16 blockn, register u_int16 *dptr) {
  SpiWaitStatus();
  
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_READ,8);
  SpiPrivSendReceive(blockn>>7,8);            // Address[23:16] = blockn[14:7]
  SpiPrivSendReceive((blockn<<1),8);     // Address[15:8]  = blockn[6:0]0
  SpiPrivSendReceive(0x00,8);                    // Address[7:0]   = 00000000
  {
      register int n;
    for (n=0; n<256; n++){
      if (*dptr++ != SpiPrivSendReceive(0,16)) {
	  USEX(GPIO_ODATA) |= SPI_xCS;
	return 1;
      }
    }
  }
  USEX(GPIO_ODATA) |= SPI_xCS;
  return 0;
}
#endif

/// Write a block to EEPROM. Caution: Does not erase block
/// \param blockn number of sector to write: 0..32767 (16Mbytes)
/// \param dptr pointer to data block
u_int16 SpiWriteBlock(u_int16 blockn, register u_int16 *dptr) {
  
//  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
//  SingleCycleCommand(SPI_EEPROM_COMMAND_CLEAR_ERROR_FLAGS);
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);

#if 0
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_WRITE_STATUS_REGISTER,8);
  SpiPrivSendReceive(0x02,8); //Sector Protections Off
  USEX(GPIO_ODATA) |= SPI_xCS;
#endif

  SpiWaitStatus();
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_WRITE,8);
  SpiPrivSendReceive(blockn>>7,8);            // Address[23:16] = blockn[14:7]
  SpiPrivSendReceive((blockn<<1),8);     // Address[15:8]  = blockn[6:0]0
  SpiPrivSendReceive(0,8);                    // Address[7:0]   = 00000000
 
  {
      register u_int16 n;
    for (n=0; n<128; n++){
      SpiPrivSendReceive(*dptr++, 16);
    }
  }
  USEX(GPIO_ODATA) |= SPI_xCS;

  SpiWaitStatus();
  SingleCycleCommand(SPI_EEPROM_COMMAND_WRITE_ENABLE);
  USEX(GPIO_ODATA) &= ~SPI_xCS;
  SpiPrivSendReceive(SPI_EEPROM_COMMAND_WRITE,8);
  SpiPrivSendReceive(blockn>>7,8);       
  SpiPrivSendReceive(((blockn<<1)+1),8); // Address[15:8]  = blockn[6:0]1
  SpiPrivSendReceive(0,8);              
  
  {
      register int n;
    for (n=128; n<256; n++){
      SpiPrivSendReceive(*dptr++,16);
    }
  }
  USEX(GPIO_ODATA) |= SPI_xCS;
  SpiWaitStatus();

  return 0;
}




#if 1
#define EEPROM_PAGE_SIZE_BITS 5
#define EEPROM_PAGE_SIZE (1<<EEPROM_PAGE_SIZE_BITS)

u_int16 SpiBlockWrite(u_int16 addr, register u_int16 *buf, u_int16 len) {
    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_WREN, 8);
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;

    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_WRITE, 8);
    if (largeAddr) {
	SpiPrivSendReceive(0, 8); //24-bit address
    }
    SpiPrivSendReceive(addr, 16);
    while (len--) {
	SpiPrivSendReceive(*buf, 16);
	addr += 2;
	buf++;
    }
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
    return addr;
}

u_int16 SpiVerify(u_int16 addr, register u_int16 *buf, u_int16 len) {
    u_int16 dat;

    USEX(GPIO_ODATA) |= SPI_xCS;
    SpiPrivDelay();
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiPrivSendReceive(SPI_READ, 8);
    SpiPrivDelay();
    if (largeAddr) {
	SpiPrivSendReceive(0, 8); //24-bit address
    }
    SpiPrivSendReceive(addr, 16);
    SpiPrivDelay();

    while (len--) {
	if (SpiPrivSendReceive(0, 16) != *buf++) {
	    SpiPrivDelay();
	    USEX(GPIO_ODATA) |= SPI_xCS;
	    return -1;
	}
    }
    SpiPrivDelay();
    USEX(GPIO_ODATA) |= SPI_xCS;
    return 0;
}

u_int16 BlockProgram(u_int16 addr, u_int16 *buf, s_int16 words) {
    register s_int16 i, len = words;
    for (i=0;i<len;) {
	register u_int16 sz = (((addr&~(EEPROM_PAGE_SIZE-1))+EEPROM_PAGE_SIZE)
			       - addr) / 2;
	if (sz > len-i)
	    sz = len-i;
	SpiBlockWrite(addr, buf+i, sz);
	i += sz;
	addr += 2*sz;
	while (SpiPrivStatus() & 1)
	    SpiPrivDelay();
    }
    return SpiVerify(addr - 2*len, buf, len);
}
#endif

/*

FUNCTION: main()
DESCRIPTION: RTOS, peripheral and variable initialization.
INPUTS: none
RESULT: none
SEE ALSO: 

*/
auto void SpiSendClocks(void);

#define BUF_SIZE 256
void MyMain(void) {
    FILE *fp;
    static u_int16 buf[BUF_SIZE];
    int i, len;
    unsigned long addr = 0;

    puthex(USEX(UART_DIV));
    puts(" div");

    USEX(INT_ENABLE) = 0;
    SpiPrivInit(); /* Set SPI clock etc */

    SpiID();
    /*C2 = macronix
      C215 = cardradio old version
      c814 = cardradio new version
     */
#if 0
    for(i=0;i<512;i++)
	SpiSendClocks();
#endif

#if 0
    while (1)
	SpiPrivStatus();
#endif

#if 0
    largeAddr = 1;
    puthex(SpiPrivRead(0));
    largeAddr = 0;
    puthex(SpiPrivRead(0));
    puts("");
    largeAddr = 1;
#endif
    SpiID();
#if 0
    largeAddr = 0;
    if (SpiPrivRead(0) != 0x5026) {
	largeAddr = 1;
	if (SpiPrivRead(0) == 0x5026) {
	}
    }
#endif

//    puthex(SpiPrivStatus()); /* should be 0080 or 0000 */
//    puts(" status");
#if 1
    addr = 0;
    while (addr < 0x40/*32766U*/) {
	if ((addr & 0x1f) == 0) {
	    putchar('\n');
	    puthex(addr);
	    putchar(' ');
	}
	len = SpiPrivRead(addr);
	puthex(len);
	addr += 2;
    }
    puts("");
    addr = 0;
#endif

#if 0
    if (SpiPrivRead(0) == 0x5026 && (SpiPrivRead(2)&0xff00U) == 0x4800) {
	addr = 3;
	while (1) {
	    u_int16 com = (SpiPrivRead(addr)>>8);
	    u_int16 len = SpiPrivRead(addr+1);
	    u_int16 add = SpiPrivRead(addr+3);
	    puthex(com);
	    putchar(' ');
	    putchar('l');
	    puthex(len);
	    putchar(' ');
	    putchar('a');
	    puthex(add);
	    putchar('\n');
	    addr += len+5;
	    if (com == 3)
		break;
	}
    }
    addr = 0;
/*
X: 0xc002-0xc00d In:   27, out:   27
I: 0x0000-0x0002 In:   13, out:   13
I: 0x0030-0x0455 In: 4249, out: 4249
*/
#endif


    fp = fopen("boot.img", "rb");
    if (!fp) {
	puts("Could not open boot.img!");
	goto exit;
    }
#if 0
    if (largeAddr) {
	puts("Using 24-bit address");
    } else {
	puts("Using 16-bit address");
    }
#endif
    while (len = fread(buf, 1, BUF_SIZE, fp)) {
#ifdef EEPROM_PAGE_SIZE
#ifdef USE_FLASH
	if (largeAddr) {
	    if (0) {
		if ((addr & 65535) == 0) {
		    putchar('C');
		    SpiEraseBlock(addr);
		}
	    } else {
		if ((addr & 4095) == 0) {
		    putchar('C');
		    Erase4kBlock(addr);
		}
	    }
	}
#endif
	if (largeAddr) {
	    SpiWriteBlock(addr/512, buf);
	    if (SpiVerify(addr, buf, len)) {
		putchar('x');
	    } else {
		putchar('.');
	    }
	    fflush(stdout);
	} else {
	    if (BlockProgram(addr, buf, len)) {
		putchar('x');
	    } else {
		putchar('.');
	    }
	    fflush(stdout);
	}
	addr += len*2;
#else
	for (i=0;i<len;i++) {
	    SpiPrivWrite(addr, buf[i]);
	    if (!(addr & 15)) {
		putchar('.');
		fflush(stdout);
	    }
	    while (SpiPrivStatus() & 1) {
		SpiPrivDelay();
	    }
#if 1
	    if (buf[i] != SpiPrivRead(addr)) {
		puthex(addr);
		putchar(' ');
		puthex(SpiPrivRead(addr));
		putchar('\n');
	    }
#endif
	    addr += 2;
	}
#endif
    }
    fclose(fp);

    puts("\nFinished!!\n");
    fflush(stdout);
 exit:
#if 0
    {
	int i;
	for (i=0;i<61;i++)
	    putch(0x10);
	while ((USEX(UART_STATUS) & UART_ST_TXRUNNING))
	    ;
    }
#endif
    ((void (*)(void))(0x4000))();
}
