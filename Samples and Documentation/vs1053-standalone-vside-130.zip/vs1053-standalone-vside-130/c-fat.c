#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "standalone.h"


#if 0
struct Fat {
    byte BS_jmpBoot[3];         /**< 0 x86 Boot Jump Code */
    byte BS_OEMName[8];         /**< 3 Formatter's name, usually "MSWIN4.1" */
      
    word BPB_BytsPerSec;        /**< 11 Bytes per sector (512) */
    byte BPB_SecPerClus;        /**< 13 Sectors per Cluster (1,2,4,8,..,128) */
    word BPB_RsvdSecCnt;        /**< 14 Reserved sectors (1 (32 for FAT32)) */
    byte BPB_NumFATs;           /**< 16 Number of FATs (2) */
    word BPB_RootEntCnt;        /**< 17 FAT12/16 n of root dir entries */
    word BPB_TotSec16;          /**< 19 Old sector count (0 for FAT32) */
    byte BPB_Media;             /**< 21 Media Type (eg 0xF8) */
    word BPB_FATSz16;           /**< 22 Size of one FAT16 in sectors */
    word BPB_SecPerTrk;         /**< 24 Old CHS Sectors Per Track */
    word BPB_NumHeads;          /**< 26 Old CSH Number of Heads */
    u_32 BPB_HiddSec;           /**< 28 n of sectors before this volume */
    u_32 BPB_TotSec32;          /**< 32 New sector count (0 for FAT12/16) */
     
    /** FAT type specific extensions */
    union Extensions{   
  
        /** FAT12/16 specific extensions to Bios Parameter Block*/
        struct Fat16Specific {    
          byte BS_DrvNum;         /**< 36 DOS INT13 Drive Number (0x80=HD)*/
          byte BS_Reserved1;      /**< 37 For WINNT; Format to 0 */
          byte BS_BootSig;        /**< 38 0x29 if next 3 fields are present */
          byte BS_VolID[4];       /**< 39 Volume ID (usually format datetime) */
          byte BS_VolLab[11];     /**< 43 Volume Label */
          byte BS_FilSysType[8];  /**< 54 Decorative name of fs, eg "FAT16   "*/
        } _16;
  
        /** FAT32 specific extensions to Bios Parameter Block*/
        struct Fat32Specific {    
          u_32 BPB_FATSz32;       /**< 36 Size of one FAT32 in sectors */
          word BPB_ExtFlags;      /**< 40 Flags; active FAT number etc */
          word BPB_FSVer;         /**< 42 File System Version (0x0000) */
          u_32 BPB_RootClus;      /**< 44 Start cluster of Root Dir. (2) */
          word BPB_FSInfo;        /**< 48 Start sector of FSINFO in Resvd area */
          word BPB_BkBootSec;     /**< 50 Sector in Resvd area for BkBoot (6) */
          byte BPB_Reserved[12];  /**< 52 Reserved, Always 0. */
          byte BS_DrvNum;         /**< 64 DOS INT13 Drive Number (0x80=HD) */
          byte BS_Reserved1;      /**< 65 For WINNT, Format to 0 */
          byte BS_BootSig;        /**< 66 0x29 if next 3 fields are present */
          byte BS_VolID[4];       /**< 67 Volume ID (usually format datetime) */
          byte BS_VolLab[11];     /**< 71 Volume Label */
          byte BS_FilSysType[8];  /**< 82 Decorative name of fs, eg "FAT32   "*/
        } _32;
      } ext;
    } fat;
#endif

#if 1
auto u_int16 GetByte(register __c0 u_int16 n);
#else
auto u_int16 GetByte(register __c0 u_int16 n) {
    register u_int16 *p = stream_buffer[n>>1];
    if (n & 1) {
	n = *p;
    } else {
	n = *p >> 8;
    }
    return n & 0xff;
}
#endif
#if 1
auto u_int16 GetWord(register __c0 u_int16 n);
#else
auto u_int16 GetWord(register __c0 u_int16 n) {
    return GetByte(n) | (GetByte(n+1)<<8);
}
#endif
#if 1
auto u_int32 GetLong(register __c0 u_int16 n);
#else
auto u_int32 GetLong(register __c0 u_int16 n) {
    return GetWord(n) | ((u_int32)GetWord(n+2)<<16);
}
#endif

#ifdef FATINFO_IN_Y
__mem_y struct FATINFO fatInfo;
#else
struct FATINFO fatInfo;
#endif

#if 0 //def USE_DEBUG
void PrintDiskSector(void) {
    register int i;
    register int j;
    for (i=0;i<512;i+=16) {
	puthex(i);
	putchar(' ');
	putchar(' ');
	for (j=0;j<16;j++) {
	    puthex2(GetByte(i+j));
	    putchar(' ');
	}
	putchar(' ');
	for (j=0;j<16;j++) {
	    register int t = GetByte(i+j);
	    if ((t & 0x7f) < 0x20)
		putchar('?');
	    else
		putchar(t);
	}
	putchar('\n');
    }
}
#endif

#if 1
auto u_int16 InitFileSystem(void);
#else
auto u_int16 InitFileSystem(void) {
    /* Load MBR -- the first sector on disk */
    ReadDiskSectorTo(0, stream_buffer);
  
    if (GetWord(510) != 0xaa55)
	return 0xaa55;

    #if 0 && defined(USE_DEBUG)
        /* Ok, it should be a MBR sector. Let's verify */
        if (stream_buffer[255] != 0x55aa) {
        #ifdef USE_DEBUG
              puts("!MBR");
        #endif
            return -1; /* sector 0 is not MBR. */
        }
    #endif

#if 0 && defined(USE_DEBUG)
    /* This checks that partition 1 is active. Alter code to allow
       other partition configurations. */
    if (GetByte(0x1be) == 0x80) {
    } else {
	puthex(GetByte(0x1be));
	puts(" PF!");
    }
#endif

    /* Now leave MBR and load sector 0 of partition */
    /* check for boot sector instead of partition table */
    if (GetLong(0x36)!= (((long)'1'<<24)|((long)'T'<<16)|((long)'A'<<8)|'F') &&
        GetLong(0x52)!= (((long)'3'<<24)|((long)'T'<<16)|((long)'A'<<8)|'F')
        ) {
        #ifdef USE_DEBUG
          PrintDiskSector();
          puts("");
        #endif
        fatInfo.currentSector = GetLong(0x1c6);
        ReadDiskSectorTo(fatInfo.currentSector, stream_buffer);
    }
    #ifdef USE_DEBUG
      PrintDiskSector();
    #endif
    
    {
        u_int16 BPB_BlksPerSec;

        /* Determine FAT Type (16/32) */
        /* This should be done better, but it'll do for now. */
        fatInfo.BPB_RootEntCnt = GetWord(17);
        /* FAT32 does not have separate root entries. */
        /* TODO: should detect FAT32 by BPB_FATSz16==0 */
        fatInfo.IS_FAT_32 = fatInfo.BPB_RootEntCnt ? 0 : 1;
        fatInfo.FilSysType = GetWord(54+3); /* 0x3231 for FAT12 */
        #ifdef USE_DEBUG
          puthex(fatInfo.FilSysType);
          puts("fsys");
        #endif
        #if 0
          if (!IS_FAT_32){
              if (GetByte(54+4)=='2') {/*diskSect.fat.ext._16.BS_FilSysType[4]=='2'*/) {
                  fatInfo.IS_FAT_12 = GetByte(54);
              }
          }
        #endif
        
        #if 0 && defined(USE_DEBUG)
          if (fatInfo.IS_FAT_32) {
              puts("FAT32");
          } else {
              puthex(fatInfo.BPB_RootEntCnt);
              puts(" FAT");
              puthex(GetWord(19));
              puts(" TSc16");
          }
          puthex(GetWord(54+3)); /* 3231 == '12' 3631= '16' 0000=FAT32 */
          puts(" fst");
        #endif
        #if 1 && defined(USE_DEBUG)
          putchar('\"');
          {
              register int i;
              for (i=0; i<11; i++) {
                  if (fatInfo.IS_FAT_32) {
                      putchar(GetByte(71+i));
                  } else {
                      putchar(GetByte(43+i));
                  }
              }
          }
          putchar('\"');
          putchar('\n');
        #endif
        /* OK, let's calculate */
        /* First, let's get rid of the idea that we have byte addresses
           in the file system. Nope, let's only deal in physical disk
           sectors of 512 bytes. First we convert the FAT byter per sector
           value to "512B disk sectors per fat sector" value. */

        BPB_BlksPerSec = GetWord(11) >> 9;

        /* Then we adjust the Sector per Cluster to mean physical disk
           sectors. in 99% of the cases it is already so because bytes
           per sector almost always is 512 in FAT. Maximum cluster size
           is 65536 bytes (128 disk sectors). */

        fatInfo.fatSectorsPerCluster = GetByte(13)/*BPB_SecPerClus*/ * BPB_BlksPerSec;
        #if 0 && defined(USE_DEBUG)
          puthex(fatInfo.fatSectorsPerCluster);
          puts(" FatSPC");
        #endif
	  fatInfo.totSize = GetWord(19);
	  if (fatInfo.totSize == 0)
	      fatInfo.totSize = GetLong(32);/*TotSec32*/

        fatInfo.fatStart = fatInfo.currentSector +
            (u_int32)GetWord(14)/*BPB_RsvdSecCnt*/ * BPB_BlksPerSec;
            #if 0 && defined(USE_DEBUG)
          puthex(fatInfo.fatStart);
          puts(" fatS");
            #endif
        fatInfo.rootStart = GetWord(22);/*BPB_FATSz16*/
        if (fatInfo.rootStart == 0) {
            if (!fatInfo.IS_FAT_32) 
                return 0x0b; /* should be FAT32; can not find root directory */
            fatInfo.rootStart = GetLong(36);/*BPB_FATSz32*/
        }
        /* BPB_NumFATs * BPB_BlksPerSec fits in a word (8+7 bits) */
        fatInfo.rootStart = fatInfo.rootStart * (GetByte(16)/*BPB_NumFATs*/ *
                                                 BPB_BlksPerSec)
            + fatInfo.fatStart;
            #if 0 && defined(USE_DEBUG)
          puthex(fatInfo.rootStart);
          puts(" rootS");
            #endif
        fatInfo.dataStart = fatInfo.rootStart + (fatInfo.BPB_RootEntCnt >> 4)
            - (fatInfo.fatSectorsPerCluster << 1); /*first cluster is cluster 2*/

            #if 0 && defined(USE_DEBUG)
          puthex(fatInfo.dataStart);
          puts(" dataS");
  //      puthex(fatInfo.clusters);
  //      puts(" Clustrs");
            #endif
	  fatInfo.numClusters = (fatInfo.totSize - fatInfo.dataStart) / fatInfo.fatSectorsPerCluster - 2;
    }
    return 0;
}
#endif

#if 0
/** FAT/VFAT directory record union */
union DirRecordUnion {
    /** Standard directory entry */
    struct Entry {
      byte Name[11]; 0
      byte Attr;     11
      byte NTRes;    12
      byte CrtTimeTenth; 13
      word CrtTime;  14
      word CrtDate;  16
      word LstAccDate; 18
      word FstClusHi; 20
      word WrtTime;   22
      word WrtDate;   24
      word FstClusLo; 26
      u_32 FileSize;  28
    } entry;
  
    /** Extended directory entry */
    struct LongEntry {
      byte Ord;      0
      word Name1[5]; 1 /**< characters 1-5 */
      byte Attr;     11
      byte Type;     12 /**< entry type, zero=long name component */
      byte Chksum;   13
      word Name2[6]; 14 /**< characters 6-11 */
      word FstClusLO; 26 /**< zero for long entry */
      word Name3[2]; 28 /**< characters 12-13 */
    } longentry;
  };
#endif


//#define MAX_FRAGMENTS 28//16//22
__mem_y struct FRAGMENT fragments[MAX_FRAGMENTS];

#if 1
auto __mem_y struct FRAGMENT *FragmentList(register __i2 __mem_y struct FRAGMENT *frag,
				       register __reg_b u_int32 fatCluster);
#else
auto __mem_y struct FRAGMENT *FragmentList(register __i2 __mem_y struct FRAGMENT *frag,
				       register __reg_b u_int32 fatCluster) {
    register __d0 u_int16 offset;
  
    /* fatCluster means now current cluster. */
    /* note that startcluster=2 is already compensated in fatInfo.dataStart
       by InitFilesystem. */
    #if 0 && defined(USE_DEBUG)
        puthex(fatCluster>>16);
        puthex(fatCluster);
        puts(" fatC");
    #endif
    #if 0
        frag->size = 0;
        frag->start = fatCluster * fatInfo.fatSectorsPerCluster + fatInfo.dataStart;
    #endif
    goto l55; /* read first sector */
  
    while (1) {
	u_int32 t;
	if (fatInfo.IS_FAT_32) {
	    t = GetLong(offset) & 0x0fffffffUL;
	} else {
            #if 0 && defined(USE_DEBUG)
	    {
		register int i;
		for (i=0;i<256;i++) {
		    t = GetByte(i);
		    puthex(t);
		    putchar(' ');
		    if ((i&7)==7)
			putchar('\n');
		}
	    }
            #endif

            t = GetWord(offset);
            if (t >= 0xfff8U)
                t = 0x0fffffffUL;
        }
        #if 0 && defined(USE_DEBUG)
          puthex(t>>16);
          puthex(t);
          puts(" c");
        #endif
        frag->size += fatInfo.fatSectorsPerCluster;
        ++fatCluster;
        if (frag->size >= 32768U || t != fatCluster) {
            /* if not sequential cluster, start next fragment */
            #if 0 && defined(USE_DEBUG)
              puts(" frag");
            #endif
            fatCluster = t;
            if (frag == &fragments[MAX_FRAGMENTS-1] ||
                t >= 0x0ffffff8UL) {
                frag->start |= LAST_FRAGMENT;
                return frag+1;
            }
            frag++;
        l55:
            frag->size = 0;
            frag->start =
                fatCluster * fatInfo.fatSectorsPerCluster + fatInfo.dataStart;

        } else {
            offset += (fatInfo.IS_FAT_32 ? 4 : 2);
            offset &= 511;
            if (offset != 0)
                continue;
        }
read:
        /* If FAT page is not already in memory, load it. */
        if (fatInfo.IS_FAT_32) {
            offset = ((u_int16)fatCluster & 0x7F) << 2;
            ReadDiskSectorTo((fatCluster >> 7) + fatInfo.fatStart, stream_buffer);
        } else {
            offset = ((u_int16)fatCluster & 0xff) << 1;
            ReadDiskSectorTo((fatCluster >> 8) + fatInfo.fatStart, stream_buffer);
        }
    }
}
#endif

u_int16 gFileNum[2];
extern __mem_y s_int16 mallocAreaY[9216];

#ifdef __VSDSP__
auto s_int16 OpenFile(register __c0 u_int16 fileNum);
#else
auto s_int16 OpenFile(register __c0 u_int16 fileNum) {
    register __i1 __mem_y struct FRAGMENT *curFragment = &fragments[0];
    register __i0 __mem_y struct FRAGMENT * __mem_y nextFragment;
    
    /* Start at the start of root directory. */
    
    if (fatInfo.IS_FAT_32) {
	nextFragment = FragmentList(curFragment, 2);
    } else {
	curFragment->start = fatInfo.rootStart | LAST_FRAGMENT;
	curFragment->size  = (fatInfo.BPB_RootEntCnt >> 4); /* /sectorsPerCluster?*/
	nextFragment = curFragment + 1;
    }
    gFileNum[0] = fileNum;
    gFileNum[1] = 0;
    return HandleDir(curFragment, nextFragment);
}
#endif

#ifdef CHECKFILETYPE
#if 0
#define MKID(a,b,c) ((a)|((b)<<8)|((u_int32)(c)<<16))
auto s_int16 CheckFileType(register __a u_int32 name) {
    name &= 0x00ffffffUL;
    if (name == MKID('W','A','V'))
	return -1;
    if (name == MKID('M','P','3'))
	return -1;
    if (name == MKID('M','I','D'))
	return -1;
    if (name == MKID('W','M','A'))
	return -1;
    if (name == MKID('A','S','F'))
	return -1;
    if (name == MKID('A','A','C'))
	return -1;
    if (name == MKID('M','P','4'))
	return -1;
    if (name == MKID('M','4','A'))
	return -1;
    if (name == MKID('3','G','P'))
	return -1;
    if (name == MKID('3','G','2'))
	return -1;
    if (name == MKID('O','G','G'))
	return -1;
    return 0;
}
#endif/*1*/
#endif/*CHECKFILETYPE*/


/*147 words*/
auto s_int16 HandleDir(register __i2 __mem_y struct FRAGMENT *curFragment,
		       __mem_y struct FRAGMENT *nextFragment) {
    register __c1 int i = 0;
    register u_int32 currentSector = curFragment->start /*& 0x7fffffffUL */;
  
#pragma msg 36 off
    goto first;
  
    while (1) {
	register __d1 u_int16 fn = GetByte(i+0); /* first char of filename */
  
#pragma msg 36 on
	/* We are now looking at FAT directory structure. */
	/* Is current file a regular file? */
	if (fn == 0) {
	    /* End of directory, stop processing immediately. */
	    goto eod;
	}
	if (fn != 0xe5) { /* Not deleted */
	    u_int32 cluster = ((u_int32)GetWord(i+20) << 16) + GetWord(i+26);
	    /* Is it a subdirectory? */
	    if ((GetByte(i+11/*Attr*/) & 0x10) && fn != '.') {
		/* TODO: do not call if FAT12! */
		if (HandleDir(nextFragment,
			      FragmentList(nextFragment, cluster)) < 0) {
		    return -1;
		}
		memset(stream_buffer, 0, 512/2);
		ReadDiskSectorTo(currentSector, stream_buffer);/*reread sector*/
	    } else if ((GetByte(i+11/*Attr*/) & 0xde) == 0
		       /* Attributes: NO directory, NO volume id, NO system, NO hidden */
		       /*
			 check supported files from name suffix:
			 vs1053: wav mp3 mid wma asf mp4 aac m4a ogg fla
		       */
		       && CheckFileType1053(GetLong(i+8))) {

		/* remember the highest used non-directory cluster */
		if (mmc.usedTopCluster < cluster) {
		    mmc.usedTopCluster = cluster;
		}

		/* It is a regular file. */
		/* If open-by-name, check name and open file if match. */
#pragma msg 240 off
		if (USEX(SCI_AICTRL3) & CTRL3_BY_NAME) {
		    register int j, t = 0;
		    register u_int16 *p = stream_buffer + i/2;
		    register __mem_y u_int16 *d = fileName;
		    for (j=0; j<5; j++) {
			t |= *d++ ^ *p++;
		    }
		    if ((((*d ^ *p) & 0xff00) | t) == 0) {
			/*if match, save the file number and open this one*/
			USEX(SCI_AICTRL0) = gFileNum[1];
			goto thisfile;
		    }
		}
#pragma msg 240 on
//fatInfo.currentSector = currentSector;
		/* If iterate flag is set, call the callback function. */
		if (USEX(SCI_AICTRL3) & CTRL3_ITERATE) {
		    IterateFilesCallback(stream_buffer+i/2);
		}

                gFileNum[1]++; /* keep track of total file count */
                if (gFileNum[0]-- == 0) {
                    /* ------------ FILE FOUND ------------- */
                thisfile:
		    /* Put the 8.3-character filename to memory so the user
		       can read it. Two bytes per word, big-endian. */
		    memcpyXY(fileName, stream_buffer+i/2, 6);

		    fatInfo.dirSector = currentSector & 0x7fffffffUL;
		    fatInfo.dirLine = i;
                    fatInfo.fileSize = GetLong(i+28); /*do first!*/
                    FragmentList(&fragments[0], cluster);
                    return -1; /* File found, All OK return */
                }
            } /* normal file */
        } /* 0xe5 / 0x00 deleted or unused entry */

	/* Advance to the next directory entry. */
        i = (i + 32) & 511;
        if (i == 0) {
            currentSector++;
            if (--(curFragment->size) == 0) {
                if ((s_int16)(curFragment->start>>16) < 0) {
		    /* End of cluster chain, end of directory. */
		eod:
		    USEX(SCI_AICTRL3) &= ~CTRL3_BY_NAME;
                    return (s_int16)gFileNum[1];
                }
                curFragment++;
                currentSector = curFragment->start /*& 0x7fffffffUL*/;
            }
        first:
	    memset(stream_buffer, 0, 512/2);
            ReadDiskSectorTo(currentSector, stream_buffer);
        }
    }
}


