#include <stdio.h>

unsigned char buffer[8192];

int main(int argc, char *argv[]) {
    int c, type, addr, size;

    c = fgetc(stdin);
    if (c != 'P')
	return 1;
    c = fgetc(stdin);
    if (c != '&')
	return 1;
    c = fgetc(stdin);
    if (c != 'H')
	return 1;

    while (1) {
	type = fgetc(stdin);
	size = fgetc(stdin);
	size = (size<<8) + fgetc(stdin);
	addr = fgetc(stdin);
	addr = (addr<<8) + fgetc(stdin);
	if (size) {
	    fread(buffer, size, 1, stdin);
	}
	if (type == 0) {
	    int i, n = size/4;
	    //printf("I:0x%04x\n", addr);
	    printf("\n\n\t.sect code,code0x%04x\n", addr);
	    printf("\t.org 0x%04x\n\n", addr);
	    for (i=0;i<n;i++) {
		unsigned long l =
		    ((unsigned long)buffer[4*i+0]<<24)|
		    ((unsigned long)buffer[4*i+1]<<16)|
		    ((unsigned long)buffer[4*i+2]<<8)|
		    ((unsigned long)buffer[4*i+3]<<0);
		printf("\t.uword 0x%08lx\n", l);
	    }
	} else if (type == 1) {
	    int i, n = size/2;
	    //printf("X:0x%04x\n", addr);
	    printf("\n\n\t.sect data_x,data_x0x%04x\n", addr);
	    printf("\t.org 0x%04x\n\n", addr);
	    for (i=0;i<n;i++) {
		unsigned long l =
		    ((unsigned long)buffer[2*i+0]<<8)|
		    ((unsigned long)buffer[2*i+1]<<0);
		printf("\t.uword 0x%04lx\n", l);
	    }
	} else if (type == 2) {
	    int i, n = size/2;
	    //printf("Y:0x%04x\n", addr);
	    printf("\n\n\t.sect data_y,data_y0x%04x\n", addr);
	    printf("\t.org 0x%04x\n\n", addr);
	    for (i=0;i<n;i++) {
		unsigned long l =
		    ((unsigned long)buffer[2*i+0]<<8)|
		    ((unsigned long)buffer[2*i+1]<<0);
		printf("\t.uword 0x%04lx\n", l);
	    }
	} else if (type == 3) {
	    //printf("Exec 0x%04x\n", addr);
	    printf("\t.end\n");
	    break;
	}
    }
    return 0;
}
