/* For reference only, there are asm implementations in this solution */
#ifdef UART_BUFFERED
#if 0
void putstrp(register __i2 u_int16 *p) {
    while (*p) {
	putch((s_int16)*p>>8);
	if (!(*p & 255))
	    break;
	putch(*p);
	p++;
    }
}
#endif
#if 0
void putstrpy(register __mem_y u_int16 *p) {
    while (*p & 0xff00) {
	putch((s_int16)*p>>8);
	if (!(*p & 255))
	    break;
	putch(*p);
	p++;
    }
}
#endif
#endif
