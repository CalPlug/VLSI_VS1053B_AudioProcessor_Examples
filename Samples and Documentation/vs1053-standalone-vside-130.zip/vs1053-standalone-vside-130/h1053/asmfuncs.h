#ifndef ASMFUNCS_H
#define ASMFUNCS_H

#ifdef __VSDSP__
#include <vstypes.h>

void WriteToProgramRam(register __i0 addr,
		       register __a1 msB, register __a0 lsB);
u_int32 ReadFromProgramRam(register __i0 addr);
u_int32 ReadIMem(register __i0 u_int16 addr);
void WriteIMem(register __i0 u_int16 addr, register __a u_int32 code);
auto void Sleep(void);
//auto void StereoCopy(register __i2 s_int16 *s, register __a0 u_int16 n);
auto void StereoCopy1053(register __i2 s_int16 *s, register __a0 u_int16 n);
auto void OldStereoCopy(register __i2 s_int16 *s, register __a0 u_int16 n);

void Disable(void);	/* NOT auto */
void Enable(void);	/* NOT auto */

void rle_sdi_int(void);
void sdi_int(void);

#endif

#endif
