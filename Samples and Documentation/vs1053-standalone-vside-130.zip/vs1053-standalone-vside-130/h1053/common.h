#ifndef COMMON_H
#define COMMON_H

#define FRAMESPACE (1792+512)

extern u_int16 __y bsspace[FRAMESPACE/2];

auto void InitReadFrame(void);
auto s_int16 ReadFrame(void);
#ifdef USE_VORBIS
void VorbisEntry(void);
#endif/*USE_VORBIS*/
#ifndef VS1003
s_int16 FastForwardSkipFrame(void); /* returns 1 if should skip a frame */
#endif /*!VS1003*/
auto void DecodeTime(register __a0 u_int16 samples,
		     register __a1 u_int16 limit,
		     register __b s_int32 bytes /*negative to disable HDAT0*/);
auto void DecodeTimeClear(void);
void ChangeWmaClock(register s_int16 *cnt);
void RealTimeMidi(void); /* in IROM4 */
void OutOfStreamData(void);

#endif
