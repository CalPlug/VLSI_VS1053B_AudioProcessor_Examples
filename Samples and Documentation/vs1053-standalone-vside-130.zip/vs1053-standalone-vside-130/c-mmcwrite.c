#include "standalone.h"

#define 	MMC_WRITE_BLOCK   24

void MmcWrite(u_int32 firstBlock, u_int16 *data) {
    register u_int16 c;
#if 0
    if (mmc.state != mmcOk || mmc.errors) {
	break;
    }
#endif

    c = MmcCommand(MMC_WRITE_BLOCK|0x40, firstBlock<<mmc.hcShift);
    //wait for BUSY token, if you get 0x01(idle), it's an ERROR!
    {
	register int __d0 t = 0;
	while (c != 0x00) {
	    /* timeout */
	    if (++t < 0 || c == 0x01) {
#if 0
		puthex(c);
		puts("=write fail");
#endif
		//mmc.errors++;
		goto out;
	    }
	    c = SpiSendReceiveMmc(0xff00, 8);
	}
    }
    SpiSendReceiveMmc(0xfffe, 16);
    for (c=0; c<257; c++) { /*one extra for dummy CRC*/
	SpiSendReceiveMmc(*data++, 16);
    }
    /* wait until MMC write finished */
    do {
	/*TODO: timeout?*/
    } while ( SpiSendReceiveMmc(0xff00U, 8) != 0x00ffU);
 out:
    SpiSendClocks();
}
