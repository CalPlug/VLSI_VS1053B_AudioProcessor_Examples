#ifndef __FLAC_H__
#define __FLAC_H__

/*2-channel: 2274 words, n-channel 2447 words (+173 words) */
#ifndef MINFLAC
#define DOWN_MATRIX /* Matrix > 2 channels. Currently 6-channel takes 80MHz! */
#endif
#define STREAM_BUFFER_EXTEND 0x1800 /*0x0000 to 0x17ff*/

#ifndef ASM
#include <stdio.h>

/* Integers */

#ifndef VSMPG_H
typedef short           s_int16;
typedef unsigned short  u_int16;
typedef long            s_int32;
typedef unsigned long   u_int32;

#ifdef __VSDSP__
typedef __fract s_int16 f_int16;
typedef __fract s_int32 f_int32;
#endif
#endif

#ifdef __VSDSP__
typedef u_int16 flac_sample_t;
#else
typedef s_int32 flac_sample_t;
#endif

#ifndef M_PI
#   define M_PI 3.141592653589793238462643
#endif

/* Special definitions */

#ifndef __VSDSP__
#define memsetY(a,b,c) memset(a,b,c)
#define auto
#define __d1
#define __d0
#define __c1
#define __c0
#define __b1
#define __b0
#define __a1
#define __a0
#define __i0
#define __i1
#define __i2
#define __i3
#define __d
#define __c
#define __b
#define __a
#define __d1
#define __far
#define __x
#define __y

#else /* VSDSP */

#endif /* !VSDSP */

/* Assertions */

#define VASSERT assert

#ifdef __VSDSP__
extern u_int16 g_dctlo[2048];
extern __y u_int16 g_dcthi[2048];
#define RDSAMP(s) ((s_int32)*(u_int16 *)(s)|((s_int32)*(__y u_int16 *)(s)<<16))
#define WRSAMP(s,w) do{register __d s_int32 wr=(w);*(u_int16 *)(s)=(u_int16)wr; *(__y u_int16 *)(s)=(u_int16)(wr>>16);}while(0)
#else
#define RDSAMP(s) (*(s))
#define WRSAMP(s,w) (*(s)=(w))
extern s_int32 g_sample[2048];
#endif
extern s_int16 g_others[2048];
extern s_int16 g_yprev0[];
extern s_int16 g_yprev1[];

/* Exit reason */

#ifdef __VSDSP__
#else
extern const char *g_message;
#define PACKED_STR ""
#endif


void memclearXY(register __i0 u_int16 *p, register __a0 s_int16 c);

/* wmabits.c */

#ifndef STANDALONE
void aacStreamReset(FILE *file);
#else
void aacStreamReset(void);
#endif
auto void WaitForAacData(register __a0 s_int16 n);
auto s_int16 StreamDiff(void);
auto s_int16 WMyGetC(void);
void aacStreamSeek(u_int32 bitpos);
void SkipData(u_int32 bytes);
void StreamDiscard(void);
auto void aacDiscardAndWait(register __a0 s_int16 n);
int aacInitBitstream( void );
extern __y u_int32 bitcount;
auto u_int16 aac_getbits(register __a1 u_int16 number_of_bits);
auto u_int32 aac_getbits32(register __a1 u_int16 number_of_bits);
u_int16 aac_get1bit( register __b s_int32 );
u_int16 aac_peekbits( int number_of_bits );
void aac_bytealign(void);

#define MAX_ORDER 32

extern struct FLAC {
  int invalid;
  int reserved;
  int chConfig, channels, sampleSize, blockSize;
  long rate;
  u_int32 pos[2];
} flac;
void FlacDecode(void);


auto s_int16 WmaStereoCopy(s_int16 *buf, s_int16 cnt);
auto void SetHardware(register s_int16 channels, register u_int16 rate);
void SetRate(register __c1 u_int16 rate);
auto void AudioSet(u_int16 ch, u_int16 r);
extern __y u_int16 hwSampleRate;

#define MKID1(a,b) (((u_int16)(a)<<8)|(b))
#define MKID(a,b,c,d) (((u_int32)(((u_int16)(a)<<8)|(b))<<16)|(((u_int16)(c)<<8)|(d)))


extern s_int16 FastForwardSkipFrame(void); /* support routine */
auto void DecodeTime(register __a0 u_int16 samples,
		     register __a1 u_int16 limit,
		     register __b u_int32 bytes);
extern void ChangeAacClock(register s_int16 *cnt);
extern void OutOfStreamData(void);
auto s_int16 AudioBufFill(void);
#ifndef STANDALONE
extern int out_of_wav;
#endif
extern __y const s_int16 i_twiddle_iv[2048+1024+512+256+128+64+32];

#if defined(STANDALONE) && defined(STREAM_BUFFER_EXTEND)
void flacStreamBufferExtend(void);
void flacStreamBufferRestore(void);
#endif


extern u_int16 crc8_table[256];
#define UPDCRC8(c,d) (crc8_table[((c)^(d))&255])


#endif /*ASM*/


#endif /*!__FLAC_H__*/
