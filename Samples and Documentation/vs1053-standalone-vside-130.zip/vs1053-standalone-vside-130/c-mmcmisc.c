#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "standalone.h"

#if 1
auto u_int16 MmcCommand(register __b0 s_int16 cmd, register __d u_int32 arg);
#else
auto u_int16 MmcCommand(register __b0 s_int16 cmd, register __d u_int32 arg) {
    register __b1 u_int16 t;
    #if 1
        puts("Cmd(");
	puthex(cmd);
	puthex(arg>>16);
	puthex(arg);
	puts(")");
    #endif
    /* some MMC brands require the extra clock pulses     */
    SpiSendClocks();
    SpiSendClocks();
    USEX(GPIO_ODATA) &= ~SPI_xCS2;
  
    while (SpiSendReceiveMmc(0xff00,8) != 0xff) {
	/* Unexpected busy signal from MMC */
        #ifdef USE_DEBUG
	    putchar('u');
            putchar('\n');
        #endif
    }
    SpiSendReceiveMmc(cmd, 16); /* top half normally 0xff */
    SpiSendReceiveMmc(arg>>16, 16);
    SpiSendReceiveMmc(arg, 16);
    t = SpiSendReceiveMmc(0x9500, 8);    /* Valid CRC for init, then don't care */
  
    cmd = 100;               /* timeout value, try max. 100 times */
    while (cmd && (t & 0x80)) { /* R1 response not detected */
	t = SpiSendReceiveMmc(0xff00, 8);
	cmd--;               /* decrease the timeout value */
    }
    #ifdef USE_DEBUG
        puthex(t);
        putchar('\n');
    #endif
    return t;
}
#endif

#if 1
auto void ReadDiskSectorTo(register __a u_int32 sector, register __i2 u_int16 *buffer);
#else
auto void ReadDiskSectorTo(register __a u_int32 sector, register __i2 u_int16 *buffer) {
    register s_int16 i;
  
    #if 0 && defined(USE_DEBUG)
        //puthex(sector>>16);
        puthex(sector);
        puts(" SECTOR");
    #endif

    MmcCommand(MMC_READ_SINGLE_BLOCK|0x40,(sector&0x7fffffffUL)<<mmc.hcShift);
    do {
        i = SpiSendReceiveMmc(0xff00,8);
        #if 0 && defined(USE_DEBUG)
          puthex(i);
          puts(" wait");
        #endif
    } while (i == 0xff);

    #if 0
      if (i != 0xfe) {
          SpiSendClocks();/*USEX(GPIO_ODATA) |= SPI_xCS2;*/
          #ifdef USE_DEBUG
            puts("wfd fail");
          #endif
          return;
      }
    #endif
    
    for (i=0; i<512; i+=2) {
        *buffer++ = SpiSendReceiveMmc(0xffff,16);
    }
    SpiSendReceiveMmc(0xffff,16); /* discard crc */

    /* generate some extra SPI clock edges to finish up the command */
    SpiSendClocks();
    SpiSendClocks();
    return;
}
#endif

