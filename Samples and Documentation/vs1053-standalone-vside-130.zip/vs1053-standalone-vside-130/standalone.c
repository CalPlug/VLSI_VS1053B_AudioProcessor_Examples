/// \file standalone.c -- VS1053 Stand-Alone MP3 Player Source Code
/// Copyright (C) 2005-2016 VLSI Solution Oy Tampere Finland

// See readme.txt.

/*
  Note:

  DREQ is changed in normal firmware both in SDI interrupts when the
  stream buffer becomes too full, and whenever the stream buffer becomes
  empty enough.

  So, we can use DREQ ourselves as we wish and access to it does not need to
  be protected by interrupt Disable()/Enable(). However, the normal decoding
  will still keep raising DREQ when it sees that there is space for new data.

- VS1053:
  + I2S
  + higher reference
- IN VS1053b:
  + SCLK = GPIDATA8
  + XCS  = GPIDATA9
  + SI   = GPIDATA10
  + XDCS = GPIDATA11
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "standalone.h"
#ifdef USE_FLAC
#include "flaclib.h"
#endif

int csCancel = 0;

void Monitor(void);

#if 1 /*for extra inits*/
extern s_int16 __mem_y needCheckNextHeader, haveCachedHeader;
extern u_int32 __mem_y cachedHeader;
struct frame {
#ifdef ALLOC_IN_X
    const struct al_table *alloc;
#else
    __mem_y const struct al_table *alloc;
#endif
    int stereo;
    int jsbound;
    int single;
    int II_sblimit;
    int lsf;
    int mpeg25;
    int header_change;
    int lay;
/*    void (*do_layer)(void);*/
    int error_protection;
    int bitrate_index;
    int sFreqIdx;
    int padding;
    int mode;
    int mode_ext;
    int framesize; /* computed framesize */
};
extern struct frame __mem_y fr;
extern __mem_y struct C1 {
  s_int16 fsize;
  s_int16 fsizeold;
  s_int16 ssize;
  u_int16 __mem_y *bsbuf;
  u_int16 bsOffset, bsOldOffset;
  u_int32 oldhead;
} c1;
#endif

/* See standalone.h for feature #defines. */

//#define USE_DEBUG

#if defined(SAVE_VOLUME) || defined(SAVE_POSITION)
  #define SAVE_STUFF
#endif

extern volatile s_int16 *srcWp, *srcRp;

extern __mem_y u_int16 g_dcthi[2048];
auto void play_frame(void);
void UserHook(void);

#define ENABLE_SCI_DAC_RX ((1<<INT_EN_SCI)|(1<<INT_EN_DAC)|(1<<INT_EN_RX))
#define ENABLE_SCI_SDI_DAC_RX ((1<<INT_EN_SCI)|(1<<INT_EN_SDI)|(1<<INT_EN_DAC)|(1<<INT_EN_RX))

#ifndef GPIO_IDATA
  #define GPIO_IDATA GPIO_DATA
#endif


#define SPI_xCS   1 /* GPIO */
#define SPI_CLK   8
#define SPI_MISO  4
#define SPI_MISO_SHIFT -3
#define SPI_xCS2  2
#define SPI_MOSI  1 /* DREQ */


#ifdef UART_BUFFERED
static int fileMode = 0;
#endif

typedef enum {
    spi_pause=0,
    spi_file=1,
    spi_seek=2,
    spi_waitdata=3,
    spi_data=4,
    spi_zeros=5,
    spi_record=6,
    spi_waitima=7
} SPISTATE;

SPISTATE spiState, oldSpiState;
u_int16 spiCnt;
#ifdef TIMEOUT
u_int16 timeOut;
#endif

struct SPIX { /* 0x1816 do not touch! ASM uses the structure */
    s_int32 size;
    u_int32 sector;
    u_int16 fragSize; /* TODO: make this 32-bit and multiply fragment list clusters by sectorsPerCluster. */
    __mem_y struct FRAGMENT *fragment;
    u_int32 targetSector; /*goto 6,7*/
} spix;


#ifdef HDATCHECK
  u_int16 hdatCheck;
#endif
extern __mem_y u_int16 hwSampleRate;

/* Can be done for all formats, because IdleHook is run as the main thread
   and not in interrupts. Whenever IdleHook is called, there either is
   not enough stream data anyway, or the decoder is outputting samples
   and there is not enough space in the audio buffer (thus not reading
   stream). */
u_int16 __mem_x * __mem_x stream_save;

__mem_y struct {
    u_int16 Data; /* must be first entry! Used by c.s */
    u_int16 Cnt;
    u_int16 Strobe;
    u_int16 Timer; /* Data,Cnt,Strobe,Timer must be in this order (buts.s) */
    u_int16 Key;
    s_int16 KeyTime;
} ui;


/* Generates timebase (ui.Strobe) for the UI. */
s_int16 ApplAddr(register __i0 s_int16 **d, register __a1 s_int16 mode,
		 register __a0 s_int16 n);
s_int16 ApplAddrButRef(register __i0 s_int16 **d, register __a1 s_int16 mode,
		       register __a0 s_int16 n);


#if 1
auto u_int32 NextSector(void);
#else
auto u_int32 NextSector(void) {
    spix.sector++;
    if (spix.fragSize-1 == 0) {
	if ((s_int32)spix.sector < 0) /* was last fragment */
	    return -1;
	spix.fragment++;
	spix.sector  = spix.fragment->start /*& 0x7fffffffUL*/;
	spix.fragSize = spix.fragment->size; /* *fatInfo.sectorsPerCluster*/
    } else {
	spix.fragSize = spix.fragSize-1;
    }
    return 0;
}
#endif


void SaveWord(register __c0 u_int16 addr, register __c1 u_int16 value);
#ifdef SAVE_VOLUME
int volChanged = 0;
#endif

#ifdef SAVE_STUFF
  #define SPI_WREN  0x06
  #define SPI_WRDI  0x04
  #define SPI_RDSR  0x05
  #define SPI_WRSR  0x01
  #define SPI_READ  0x03
  #define SPI_WRITE 0x02
  
register __a1 short SpiDelay(void);
auto u_int16 SpiSendReceiveSpi(register __a0 u_int16 datTopAligned, register __a1 s_int16 bits);

#if 1
void SaveWord(register __c0 u_int16 addr, register __c1 u_int16 value);
#else
void SaveWord(register __c0 u_int16 addr, register __c1 u_int16 value) {
    USEX(GPIO_ODATA) &= ~(SPI_xCS2|SPI_xCS);
    SpiSendReceiveSpi(SPI_WREN<<8, 8);
    USEX(GPIO_ODATA) |= SPI_xCS;
    USEX(GPIO_ODATA) &= ~SPI_xCS;
    SpiSendReceiveSpi(SPI_WRITE<<8, 8);
    SpiSendReceiveSpi(addr/*volume=26*/, 16);
    SpiSendReceiveSpi(value, 16);
    USEX(GPIO_ODATA) |= SPI_xCS|SPI_xCS2;//SPI_CLK;
}
#endif
  //SaveWord(26/*volume=26*/, USEX(SCI_VOL));
#endif/*SAVE_STUFF*/


#ifdef SHUFFLE_PLAY
u_int16 shuffle_offset = 0;
#endif

#ifdef USE_REWIND
int rewmode = 0;
int rewcount = 0;
#endif

// Definitions for Standalone Legacy Keys (VS1011/VS1003/VS1053) SW1, SW2, SW3
// These are read using special diode connections to the spi bus

#define SW1 0xffffU
#define SW2 0x8000U
#define SW3 0x7fffU
//#define SW4 0x4000U
      

/*
  Called before HALT
 */
void UserHook(void) {
    register __c1 SPISTATE cachedSpiState = spiState;

    // PKP: -- UI: USER INTERFACE --
    // PKP: It's time to check the buttons and do UI calculations
    if (ui.Strobe) {
	ui.Data = ui.Strobe = 0;
                  
	// PKP: -- UI: READ KEYS --

#ifdef SCI_KEYS /*If both keys and SCI control.*/
#define HAS_KEYS
	/* SCI-controlled version, but with additional key support.
	   GPIO4 for Pause/Play(short press) and Toggle Shuffle(long press), 
	   GPIO5 for Next(short) and Vol+(long), 
	   GPIO6 for Previous(short) and Vol-(long). */
	ui.Data = USEX(GPIO_IDATA) & (7<<4);/*low is idle, high when pressed*/
	//ui.Data = ~USEX(GPIO_IDATA) & (7<<4); /*high idle, low when pressed*/
	if (ui.Data == (1<<6)) {
	    ui.Data = SW2;/*prev/vol-*/
	} else if (ui.Data == (1<<5)) {
	    ui.Data = SW1;/*next/vol+*/
	} else if (ui.Data == (1<<4)) {
	    ui.Data = SW3;/*pause/play/loudness*/
	}
#else
#ifdef COMPAT_KEYS // PKP: Read the legacy 3-button keys
#define HAS_KEYS
	/*
	  This following code is compatible with the prototyping board buttons.
	  Connecting the buttons differently 4 keys could be read directly.
	*/
	if (!(USEX(GPIO_IDATA) & (1<<10)/*SI*/)) {
	    ui.Data = SW2;/*prev/vol-*/
	} else if (!(USEX(GPIO_IDATA) & (1<<11)/*XDCS*/)) {
	    ui.Data = SW1;/*next/vol+*/
	} else {
	    register u_int16 t = USEX(GPIO_ODATA);
	    USEX(GPIO_ODATA) = t & ~SPI_xCS;
	    /* Should have a short wait here, but seems to work this way.*/
	    if (!(USEX(GPIO_IDATA) & (1<<11)/*XDCS*/)) {
		ui.Data = SW3;/*play/pause/ etc*/
	    } else if (!(USEX(GPIO_IDATA) & (1<<9)/*XCS*/)) {
		ui.Data = SW3;
	    }
	    USEX(GPIO_ODATA) = t;
	}
#endif
#if defined(DIRECT_KEYS) && !defined(HAS_KEYS) // PKP: Read directly connected keys
#define HAS_KEYS
	/*
	  + SCLK = GPIDATA8
	  + XCS  = GPIDATA9
	  + SI   = GPIDATA10
	  + XDCS = GPIDATA11
	*/
	if (!(USEX(GPIO_IDATA) & (1<<10)/*SI*/)) {
	    ui.Data = SW2;/*next*/
	} else if (!(USEX(GPIO_IDATA) & (1<<11)/*XDCS*/)) {
	    ui.Data = SW1;/*prev*/
	} else if (!(USEX(GPIO_IDATA) & (1<<9)/*XCS*/)) {
	    ui.Data = SW3;/*pause/play*/
	}
	//else if (!(USEX(GPIO_IDATA) & (1<<8)/*SCLK*/)) {
	//ui.Data = SW1;/*prev*/
	//}
#endif
#endif /*elseSCI_KEYS*/


#ifdef HAS_KEYS
	// PKP: -- UI: KEY FUNCTIONS --
     
	if (ui.Data == ui.Key) { // PKP: Current Keystate is same as previous Keystate
	    if (ui.KeyTime < 8) {
		ui.KeyTime++;
	    } else // PKP: keystate has been consistent for 8 ticks - it's a long keypress
		if (ui.Key && ui.KeyTime > 0) {
		    /* long presses */
		    if (ui.Key == SW1) {
#ifdef USE_REWIND
			if (rewmode == 0)
			    rewmode = 1;
#else
#ifdef UART_BUFFERED			
			goto volup;
#else
			//volup:
			if (USEX(SCI_VOL))
			  USEX(SCI_VOL) -= 0x0101;
			goto setvol;
#endif

#endif
		    } else if (ui.Key == SW2) {
#ifdef UART_BUFFERED
			goto voldown;
#else
			//voldown:
			if (USEX(SCI_VOL) != 0xffffU)
			  USEX(SCI_VOL) += 0x0101;
		    setvol:
			;
#ifdef SAVE_VOLUME
			volChanged = 1;
#endif/*SAVE_VOLUME*/
			//putch(USEX(SCI_VOL));
			//putdec(USEX(SCI_VOL) & 255);
			//putch('\n');
			
#endif/*elseUART_BUFFERED*/
		    } else {
			if (ui.KeyTime == 8) {
			    ui.KeyTime = 9;
			    if (cachedSpiState
                              #ifdef SW3_RANDOM_PLAY
				!=
                              #else
				==
                              #endif
				spi_pause) {
				/* if pause on -- toggle random play */
				USEX(SCI_AICTRL3) ^= CTRL3_RANDOM_PLAY;
				if (USEX(SCI_AICTRL3) & CTRL3_RANDOM_PLAY) {
				    ui.Key = ui.Data;
				    #ifdef UART_BUFFERED
				    goto nextsong;
				    #else
				    USEX(SCI_AICTRL0) += 0x8001;
				    #endif
				}
			    } else {
				/* toggle loudness - have LSb set when ON */
				USEX(SCI_BASS) ^= USEX(SCI_AICTRL2);
#ifdef UART_BUFFERED
				putstrp((USEX(SCI_BASS) & 1) ? "\ploudness\n" : "\pnormal\n");
#endif
			    }
			}
		    }
		}
	    } else { // PKP: Keystate is not the same as previous keystate
		// PKP: Handle short keypresses
		if (ui.Data == 0 && ui.KeyTime > 0) {
		    // PKP: Handle end of short keypress (current keystate ui.Data=0)
		    /* short presses */
		    if (ui.KeyTime < 8) {
			/* was pressed < 0.5 seconds */
        
			if (ui.Key == SW3) {
			    /* play pause/continue -- not very good for midi.. */
			    USEX(SCI_AICTRL3) ^= CTRL3_PAUSE_ON;
#ifdef UART_BUFFERED
			    putch((USEX(SCI_AICTRL3) & CTRL3_PAUSE_ON) ? '=' : '>');
#endif
			} else if (ui.Key == SW1 || ui.Key == SW2) {
			    if (ui.Key == SW1) {
				ui.Key = ui.Data;
                                #ifdef UART_BUFFERED
				goto nextsong;
				#else
				USEX(SCI_AICTRL0) += 0x8001;
				#endif
			    } else {
				ui.Key = ui.Data;
                                #ifdef UART_BUFFERED
				goto prevsong;
				#else
				if (USEX(SCI_DECODE_TIME) < 4) {
				  if (USEX(SCI_AICTRL0) == 0) {
				    USEX(SCI_AICTRL0) =
				      USEX(SCI_AICTRL1) + (0x8000-1);
				  } else {
				    USEX(SCI_AICTRL0) += (0x8000-1);
				  }
				} else {
				  USEX(SCI_AICTRL0) |= 0x8000U;
				}
				#endif
			    }
			}
		    }//(ui.keyTime was < 8)
		}
		ui.Key = ui.Data;
		ui.KeyTime = 0;
	    }
        
            #if defined(SAVE_VOLUME)
	      /*Save volume when volume button is released. */
	      if (ui.Data == 0 &&
		  volChanged &&
		  cachedSpiState == spi_seek) {
		  volChanged = 0;
		  SaveWord(26/*volume=26*/, USEX(SCI_VOL));
	      }
            #endif/*SAVE_VOLUME*/

            //ui.Data = 0;
#endif /*HAS_KEYS*/
      }


#ifdef UART_BUFFERED
        if (UartFill() >= 1) {
            int c = UartGetByte();
	    static int uiValue = 0;
	    if (c == 0xef) {
	      USEX(INT_ENABLE) = 0;
	      Monitor();
	    } else if (c >= '0' && c <= '9') {
	      uiValue = uiValue * 10 + c - '0';
	    } else if (c == 'f') { /* filemode */
		fileMode = 1;
	    } else if (c == 'c') { /* continuous play mode - random off */
		USEX(SCI_AICTRL3) &= ~CTRL3_RANDOM_PLAY;
		fileMode = 0;
	    } else if (c == ',') { /* previous */
	    prevsong:
		if (USEX(SCI_DECODE_TIME) < 4) {
		    if (USEX(SCI_AICTRL0) == 0) {
			USEX(SCI_AICTRL0) = USEX(SCI_AICTRL1) + (0x8000-1);
		    } else {
			USEX(SCI_AICTRL0) += (0x8000-1);
		    }
		} else {
		    USEX(SCI_AICTRL0) |= 0x8000U;
		}
		putch(',');
            } else if (c == 'C') { /* Cancel */
		USEX(SCI_AICTRL0) |= 0x8000;
	    } else if (c == 'r') { /* random play */
		USEX(SCI_AICTRL3) |= CTRL3_RANDOM_PLAY;
            } else if (c == '.') { /* next */
	    nextsong:
		USEX(SCI_AICTRL0) += 0x8001;
		putch('.');
	    } else if (c == '=') { /* pause */
		//putstrp("\ppause\n");
		putch('=');
		USEX(SCI_AICTRL3) |= CTRL3_PAUSE_ON;
	    } else if (c == '>') { /* play 1x */
		USEX(SCI_AICTRL3) &= ~CTRL3_PAUSE_ON;
		parametric_x.playSpeed = 1;
		putch('>');
	    } else if (c == '�') { /* play faster */
		parametric_x.playSpeed++;
		putch(parametric_x.playSpeed);
	    } else if (c == 'V') { /* Set volume from value */
	        USEX(SCI_VOL) = (uiValue & 255) * 257;
		uiValue = 0;
		goto setvol;
	    } else if (c == '+') { /* volume up */
	    volup:
		if (USEX(SCI_VOL))
		    USEX(SCI_VOL) -= 0x0101;
		goto setvol;
	    } else if (c == '-') { /* volume down */
	    voldown:
		if (USEX(SCI_VOL) != 0xffffU)
		    USEX(SCI_VOL) += 0x0101;
	    setvol:
                #ifdef SAVE_VOLUME
		volChanged = 1;
                #endif/*SAVE_VOLUME*/
		//putch(USEX(SCI_VOL));
		putdec(USEX(SCI_VOL) & 255);
		putch('\n');
	    } else if (c == '?') { /* decode time + info -- Note: will block.*/
#ifdef USE_PRINTABLE_OUTPUT
		putdec(USEX(SCI_DECODE_TIME));
		putch(' ');
		/* play file position from 0..255 */
		putdec((fatInfo.fileSize-2*spix.size) / ((fatInfo.fileSize >> 8)+1));
		putch('\n');
#else
		putword(USEX(SCI_DECODE_TIME));
		/* play file position from 0..255 */
		putch((fatInfo.fileSize-2*spix.size) / ((fatInfo.fileSize >> 8)+1));
#endif
	    } else {
	      uiValue = 0;
		/* unknown command */
                //putch(c);
            }
        }
#endif /*UART_BUFFERED*/


      /* The following now handles the operations for all:
	 1) the UART control
	 2) the SCI control
	 3) the button control
      */


      /* play pause/continue */
      if ((USEX(SCI_AICTRL3) & CTRL3_PAUSE_ON)) {
          if (cachedSpiState != spi_pause) {
              oldSpiState = cachedSpiState;
              cachedSpiState = spi_pause;
  
              stream_save = stream_wr_pointer;
              stream_wr_pointer = stream_rd_pointer+1;
              /* Does not matter if it is one off the buffer end ..
                 StreamDiff() returns the right value regardless. */
          }
      } else {
          if (cachedSpiState == spi_pause) {
              cachedSpiState = oldSpiState;
              stream_wr_pointer = stream_save;
          }
      }
      if ((USEX(SCI_AICTRL0) & 0x8000U)) {    /* new song */
	  USEX(SCI_AICTRL0) &= 0x7fff; /* ack command */
	  USEX(SCI_MODE) |= (1<<SCIMB_OUT_OF_WAV);
	  csCancel = 1;

	  /*NEW: clear pause and file ready bits automatically */
	  USEX(SCI_AICTRL3) &= ~(CTRL3_PAUSE_ON | CTRL3_FILE_READY | CTRL3_AT_END);
	  /* Discard any unread data, including CRC, before starting again */
	  {
              register int i;
              for (i=0; i<256+2; i++)
                  SpiSendReceiveMmc(-1/*0xffff*/,16);
          }
	  SpiSendClocks(); //raise chip select
	  cachedSpiState = spi_zeros;
	  spiCnt = 0;
          /* Jump to new track immediately */
          //MyReset();
          #if defined(ENABLE_LAYER12)
	  /* gain=0 for partial last frame (bugs) TODO: do for mp2 only! */
	  //volume[0] = volume[1] = 0;
          #endif
      }
    
    #ifdef PLAYTIME
      if (USEX(SCI_DECODE_TIME) > PLAYTIME && cachedSpiState != spi_zeros) {
          USEX(SCI_AICTRL0)++;
          #if !defined(NO_MIDI)
            USEX(SCI_MODE) |= (1<<SCIMB_OUT_OF_WAV);
          #endif
          cachedSpiState = spi_zeros;
	  spiCnt = 0;
      }
    #endif/*PLAYTIME*/
    
    
    if (cachedSpiState == spi_file) { /* Play file from the beginning. */
        /* extra byte will be read if the file size is odd */
        spix.size = (fatInfo.fileSize+1)/2; /* convert to words */
        cachedSpiState = spi_seek;
setfrag:
        spix.fragment = &fragments[0];
        spix.sector   = fragments[0].start /*& 0x7fffffffUL*/;
        spix.fragSize = fragments[0].size; /*todo: *fatInfo.sectorsPerCluster*/
    }
    if (cachedSpiState == spi_seek) {
#ifdef RESTORE_POSITION
	/* Repeat/goto/restore play position - forward only. */
	if (spix.targetSector &&
	    (USEX(SCI_STATUS) & (1<<SCIST_DO_NOT_JUMP)) == 0) {
	    /* can not jump backwards */
	    if (spix.targetSector >= (spix.fragment->start & 0x7fffffff)) {
		s_int32 skip = spix.targetSector - spix.sector;
		/*jump one fragment at a time if necessary*/
		if (skip >= spix.fragSize)
		    skip = spix.fragSize-1;
		spix.sector += skip;
		spix.fragSize -= skip;
		spix.size -= skip*512/2;

		if (spix.sector == spix.targetSector)
		    spix.targetSector = 0;
	    }
	    needCheckNextHeader = 1;
	}
#endif /*RESTORE_POSITION*/

#ifdef USE_REWIND
#define REWIND_STEP_SIZE 64 /* should be bitrate-dependant, and should not rewind midi files */
	if (rewmode == 1) {
	    s_int32 skip = spix.fragment->size - spix.fragSize;
	    if (skip > REWIND_STEP_SIZE)
		skip = REWIND_STEP_SIZE;
	    spix.sector -= skip;
	    spix.fragSize += skip;
	    spix.size += skip*512/2;

	    rewcount = REWIND_STEP_SIZE/4; //how much to send before next jump
	    rewmode = 2;
	} else if (rewmode == 2) {
	    if (--rewcount == 0)
		rewmode = 0;
	}
#endif

	/* Send the SD/MMC read block command */
	MmcCommand(MMC_READ_SINGLE_BLOCK|0x40,
		   (spix.sector & 0x7fffffffUL) << mmc.hcShift);
        cachedSpiState = spi_waitdata;
        spiCnt = 0;
        #ifdef HDATCHECK
          if (++hdatCheck == HDATCHECK && USEX(SCI_HDAT1) == 0) {
              /* if file not detected at HDATCHECK/2 kB, skip the rest */
              goto end_of_file;
          }
        #endif
    }

    /*TODO: handle spi_waitdata and spi_data
      in timer interrupt to increase throughput for FLAC */
    /*
      We have sent the read block command and now check if the data
      is available to be read out.
     */
    if (cachedSpiState == spi_waitdata) {
	register u_int16 res = SpiSendReceiveMmc(0xff00,8);
	if (res == 0xfe) { /* 0xfe is the data start token */
	    cachedSpiState = spi_data; /* go to fetch mode */
	    spiCnt = 0;
            #ifdef TIMEOUT
	        timeOut = 0;
            #endif
	    NextSector();
	} else if (res == 0xff) { /* card is still fetching block */
	    if ((s_int16)++spiCnt < 0) {
		MyReset(); /* timeout, reset immediately */
	    }
	} else {
	    /* Otherwise we have Read Error, and data is not transferred */
	    goto end_of_file;
	}
    } else if (cachedSpiState == spi_data) { /* data transfer state */
	/* Loop until the whole file is read, or stream buffer is full,
	   or the next sector needs to be read. */
	while (spix.size > 0) {
	    register int i, j = 32;
	    register u_int16 *wr;
            #if defined(USE_FLAC)
                if (USEX(SCI_HDAT1) == (('f'<<8) | 'L')) {
                    register s_int16 t = stream_wr_pointer - stream_rd_pointer;
                    if (t < 0)
                        t += 0x1800;
                    if (t > 0x1800/*STREAM_BUFFER_SZ*/-40)
                        break; /* stream buffer full, leave loop */
                    wr = (void *)stream_wr_pointer;
                    if (j > spix.size)
                        j = spix.size;
                    for (i=0;i<j;i++) {
                        *wr++ = SpiSendReceiveMmc(-1/*0xffffU*/,16);
                        if (wr >= &stream_buffer[0x1800/*STREAM_BUFFER_SZ*/])
                            wr = stream_buffer;
                    }
                } else
            #endif
	    {
		if (StreamDiff() >= STREAM_BUFFER_SZ-40)
		    break; /* stream buffer full, leave loop */
		wr = (void *)stream_wr_pointer;
		if (j > spix.size)
		    j = spix.size;
		for (i=0;i<j;i++) {
		    *wr++ = SpiSendReceiveMmc(-1/*0xffffU*/,16);
		    if (wr >= &stream_buffer[STREAM_BUFFER_SZ])
			wr = stream_buffer;
		}
	    }
	    stream_wr_pointer = (void *)wr;
	    spix.size -= j;//32;
	    spiCnt += 32;
	    if (spiCnt >= 256) {
		/* 256 words read, get next block in file */
		cachedSpiState = spi_seek;
		SpiSendReceiveMmc(-1/*0xffff*/,16); /* discard crc */
		break;
	    }
            #ifdef TIMEOUT
                timeOut = 0;
            #endif
	    /* watchdog clearing here doesn't work with midi */
	}
  
        #ifdef TIMEOUT
            if ((s_int16)++timeOut == -1) {
                spix.size = 0;
            }
        #endif
    
        if (spix.size <= 0) {
end_of_file:
#if 0
putch('E');
#endif
	    {
		register int m = (USEX(SCI_AICTRL3) & CTRL3_PLAY_MODE_MASK);
		if (m == CTRL3_LOOP_SONG){
		    /* restart the same file immediately */
		    cachedSpiState = spi_file;
		} else {
		    /*NEW: pause after play */
		    if (m == CTRL3_PAUSE_AFTER_PLAY) {
			USEX(SCI_AICTRL3) |= CTRL3_PAUSE_ON | CTRL3_AT_END;
		    } else {
			USEX(SCI_AICTRL0) += 1; /* next file */
		    }
		    cachedSpiState = spi_zeros;
		    spiCnt = 0;
#ifdef USE_FLAC
		    if (USEX(SCI_HDAT1) == (('f'<<8) | 'L'))
			USEX(SCI_MODE) |= (1<<SCIMB_OUT_OF_WAV);
#endif
		}
            }
        }
        #ifdef NO_WMA /* reject WMA files */
            if (USEX(SCI_HDAT1) == (('W'<<8)|'M')) {
		USEX(SCI_AICTRL0) += 1; /* next file */
		goto goreset;//MyReset();
	    }
        #endif
        #ifdef NO_AAC /* reject AAC files */
	    {
		register u_int16 t = USEX(SCI_HDAT1);
		//0x4154(AT) 0x4144(AD) 0x4d34(M4)
		if (t == 0x4154 || t == 0x4144 || t == 0x4d34) {
		    USEX(SCI_AICTRL0) += 1; /* next file */
		    goto goreset;//MyReset();
		}
	    }
        #endif
    } else if (cachedSpiState == spi_zeros) { /* send zeros after the file */
	if (spiCnt == 0) {
            /* Discard any unread data, including CRC, before starting again */
	    register int i;
	    for (i=0; i<256+2; i++)
		SpiSendReceiveMmc(-1/*0xffff*/,16);
	}

        /* Workaround for WMA resync after stream ended! */
        parametric_x.resync = 0;

	/*TODO: different for flac */
        if (StreamDiff() < STREAM_BUFFER_SZ-40) {
            register int i, z = parametric_x.endFillByte;
            register u_int16 *wr = (void *)stream_wr_pointer;
//	    if (USEX(SCI_MODE) & (1<<SCIMB_OUT_OF_WAV)) {
//		z = 0xfffa;
//	    }
            for (i=0;i<32;i++) {
                *wr = z;
                if (wr >= &stream_buffer[STREAM_BUFFER_SZ-1]) {
                    wr = stream_buffer;
                } else {
                    wr++;
                }
                ++spiCnt;
                stream_wr_pointer = (void *)wr;
            }
            /* watchdog clearing here doesn't work with midi */
            #ifdef TIMEOUT
              timeOut = 0;
            #endif
        }
        #ifdef TIMEOUT
	if ((s_int16)++timeOut < 0) {
	    goto goreset;
	}
        #endif

	if (spiCnt >= 256+1*1024) {
	    /* Cancel play at the end of the song. */
	    USEX(SCI_MODE) |= (1<<SCIMB_OUT_OF_WAV);
	    csCancel = 1;
	}
        
        if (//USEX(SCI_HDAT1) == 0 ||
        #if 0//1
	    USEX(SCI_HDAT1) == 0x574d ||
        #endif
        #ifdef USE_FLAC
	    USEX(SCI_HDAT1) == (('f'<<8) | 'L') ||
        #endif
            spiCnt >= 256+4*2048) { /* was left to max 256 by spi_data */
            /* 2048 words instead of bytes */
goreset:
            SpiSendClocks();
            MyReset();
        }
    }
    
      #ifdef NO_DREQ_LED
	/* Save space by not updating DREQ. */
      #else /*NO_DREQ_LED*/
        /* 15 words */
        {
            register int t = 0;
    
            if ((ui.Timer & 0x18) == 0) {
                /* DREQ indicates random play status */
		t = USEX(SCI_AICTRL3);  /* lowest bit is global random play*/
		if (cachedSpiState
                #ifdef SW3_RANDOM_PLAY
		    ==
                #else
		    !=
                #endif
		    spi_pause) {
		    t = USEX(SCI_BASS); /* has lowest bit set if enabled*/
		}
            }
            USEX(SER_DREQ) = t;
        }
      #endif/*!NO_DREQ_LED*/
    
    spiState = cachedSpiState;
}



void NewSinTest(void);
auto int PatchFrame(void);
void AacSetRate(register __c1 u_int16 rate);/*Patches some AAC problems*/




#if 1
auto s_int16 StreamHeadRead(u_int32 __mem_y *newhead);
auto s_int16 StreamHeadShift(u_int32 __mem_y *head);
auto s_int16 IsMP23Header(register __d u_int32 head);
auto s_int16 HeaderCompatibility(u_int32 old, u_int32 new);
auto void ClearCommonBuffers(s_int16 clearAudio);
auto s_int16 decode_header(unsigned long newhead);
auto s_int16 StreamReadFrameBody(u_int16 __mem_y *buf, s_int16 size);
extern const u_int16 freqs[9];
auto void mymem16cpy(u_int16 __mem_y *d, s_int16 dOff, const u_int16 __mem_y *s, s_int16 sOff, s_int16 n);


auto s_int16 ReadFrame2(void) {
  u_int32 __mem_y newHead;

  c1.fsizeold = fr.framesize;
  if (haveCachedHeader) {
    newHead = cachedHeader;
    haveCachedHeader = 0;
  } else {
      StreamHeadRead(&newHead);
  }
  while (!IsMP23Header(newHead)) {
#ifdef USE_FLAC
      if (newHead == ((u_int32)((('f'<<8)|'L')<<16) | (('a'<<8)|'C'))) {
	  FlacDecode();
	  newHead = 0;
      }
#endif
    USEX(SCI_HDAT0) = 0;
    USEX(SCI_HDAT1) = 0;
    StreamHeadShift(&newHead);
    if (!needCheckNextHeader)
      needCheckNextHeader = 1;
    /* 20150922 The following added so the decoder can return after a file. */
    if (csCancel || (USEX(SCI_MODE) & (1<<SCIMB_OUT_OF_WAV))) /** << */
	return -1; /** << */
  }
  fr.header_change |= HeaderCompatibility(c1.oldhead, newHead);
  if (fr.header_change) {
    if (fr.header_change > 1) {
      ClearCommonBuffers(1);
      if (!needCheckNextHeader)
	needCheckNextHeader = 1;
    }
  }

  if (!decode_header(newHead)) {
//putstrp("\pheader failed\n");
    USEX(SCI_HDAT0) = 0;
    USEX(SCI_HDAT1) = 0;
    if (!needCheckNextHeader)
      needCheckNextHeader = 1;
    return 1;
  }

  c1.fsize = fr.framesize;       /* for Layer3 */
  c1.bsbuf = bsspace;
  c1.bsOldOffset = c1.bsOffset;
  c1.bsOffset = ((FRAMESPACE-fr.framesize-1)>>1);

  if (fr.lay == 3 && c1.fsizeold)
    mymem16cpy(c1.bsbuf, 0, c1.bsbuf, c1.fsizeold-c1.ssize, 512/*+1*/);

  StreamReadFrameBody(c1.bsbuf+c1.bsOffset,fr.framesize);
  USEX(SCI_HDAT0) = newHead;
  USEX(SCI_HDAT1) = newHead>>16;

  {
      register u_int16 s;
      if (fr.lay == 1) {
	  s = 384;
      } else if (fr.lay < 3 || fr.sFreqIdx < 3) {
	  s = 2*576;
      } else {
	  s = 576;
      }
      DecodeTime(s, freqs[fr.sFreqIdx], -(fr.framesize+4));
  }
  if (needCheckNextHeader) {
    haveCachedHeader = 1;
    StreamHeadRead(&cachedHeader);
    if (!IsMP23Header(cachedHeader) ||
	HeaderCompatibility(cachedHeader, newHead) > 1) {
      if (!needCheckNextHeader)
	needCheckNextHeader = 1;
      return 1;
    }
    if (--needCheckNextHeader)
      return 1;
  }
  /* Must be set AFTER IsMP23Header!! */
  bitindex = 0;
  wordpointer = c1.bsbuf+c1.bsOffset;
  return 0;
}
#endif




void PlayCurrentFile(void) {
    InitLayer3(); /* clears mp3 synthesis buffers etc. */
    InitCommon(); /* sets mpeg frame pointers stuff */
    //InitReaders();
    InitDecode(); /* sets synthesis phase variable */
    //InitGeneral();
    //AudioInit();

#if defined(SKIP_ID3V2) /* 48 words */
    /* check for ID3v2 */
    /* An ID3v2 tag can be detected with the following pattern:
       $49 44 33 yy yy xx zz zz zz zz */
    ReadDiskSectorTo(fragments[0].start, stream_buffer);
    if ((GetLong(0) & 0xffffffL) == 0x334449) {
	/* skip in 16kB resolution, assume tags are smaller than 2MB */
	/* 0.5kB resolution now */
	register u_int16 skip = 32 * GetByte(7) + GetByte(8)/4;
	/* guard against small fragments */
	if (skip >= fragments[0].size)
	    skip = fragments[0].size-1;
	fragments[0].start += skip;
	fragments[0].size  -= skip;
	fatInfo.fileSize -= (u_int32)skip * 512;
    }
#endif

    if ((USEX(SCI_AICTRL3) & CTRL3_PLAY_MODE_MASK) ==
	CTRL3_PAUSE_BEFORE_PLAY) {
	/* Mark file ready and go to pause state in UserHook */
	USEX(SCI_AICTRL3) |= CTRL3_PAUSE_ON;
    }
    /*NEW: set FILE_READY always */
    USEX(SCI_AICTRL3) = CTRL3_FILE_READY | (USEX(SCI_AICTRL3) & ~CTRL3_AT_END);
	
#if defined(PAUSE_AT_POWERON)
    /*pause at power-on, then use pause after play*/
    if ((USEX(SCI_AICTRL3) & CTRL3_PLAY_MODE_MASK) == CTRL3_PAUSE_BEFORE_PLAY){
	USEX(SCI_AICTRL3) = CTRL3_PAUSE_AFTER_PLAY;
	oldSpiState = spi_file;
	spiState = spi_pause;
	stream_save = stream_wr_pointer;
    } else {
	spiState = spi_file;
    }
#else /*PAUSE_AT_POWERON*/
	
#if defined(UI_PAUSE_BEFORE_PLAY)
    oldSpiState = spi_file;
    spiState = spi_pause;
    stream_save = stream_wr_pointer;
#else
    if ((USEX(SCI_AICTRL3) & CTRL3_PLAY_MODE_MASK) ==
	CTRL3_PAUSE_BEFORE_PLAY) {
	oldSpiState = spi_file;
	spiState = spi_pause;
	stream_save = stream_wr_pointer;
    } else {
	spiState = spi_file;
    }
#endif
#endif /*else PAUSE_AT_POWERON*/
	
	
#ifdef HDATCHECK
    hdatCheck = 0;
#endif

#ifdef SAVE_POSITION
    /* Save current song number to EEPROM */
    SaveWord(28/*AICTRL0*/, USEX(SCI_AICTRL0));
#endif


#ifdef UART_BUFFERED
    parametric_x.playSpeed = 1;
    putstrp("\pplay ");
#ifdef USE_PRINTABLE_OUTPUT
    putdec(USEX(SCI_AICTRL0));
#else
    puthex(USEX(SCI_AICTRL0));
#endif
    putch(' ');
    putword(fileName[0]);
    putword(fileName[1]);
    putword(fileName[2]);
    putword(fileName[3]);
    putword(fileName[4]);
    putch(fileName[5]>>8);
    putch('\n');
#endif

#if 0 //Sine Test
//      USEX(SCI_VOL) = 0;
    USEX(SCI_VOL) = 0x0404;
//      SetRate(44100U);
    SetRate(48000U);
    USEX(SCI_AICTRL0) = 2972; /*1kHz*/
    USEX(SCI_AICTRL1) = 2972;
    CallIROM4(NewSinTest);
#endif
    
    parametric_x.resync = 32767; /* enable resyncs */

    stream_rd_pointer = stream_wr_pointer = (void*)stream_buffer;
    stream_rd_odd = 0;
    /* Main decode loop -- patched version of ReadFrame() does not fix
       known decoding problems, vs1053b-patches should also be integrated. */
    InitReadFrame();

    DecodeTimeClear();
    USEX(SCI_DECODE_TIME) = 0;
    csCancel = 0;
    USEX(SCI_MODE) &= ~(1<<SCIMB_OUT_OF_WAV);
    while (1) {
	register int j;
	/* ReadFrame does not return after format XX..
	   It requires a mp3 header before returning! */
        if (
#if 0 //defined(USE_FLAC) /* Implemented in ReadFrame2 */
	    !(j = PatchFrame())
#else
	    !(j = ReadFrame2())
#endif
            ) {
            play_frame();
        } else {
            InitReadFrame();
	    needCheckNextHeader = 0;
        }
	if (csCancel || (USEX(SCI_MODE) & (1<<SCIMB_OUT_OF_WAV)))
	    break;
	UserHook();
    }
#ifdef UART_BUFFERED
    putstrp("\pend\n");
#endif
}


#ifdef UART_BUFFERED
extern __align __mem_y u_int16 uartRxBuffer[32];
extern __mem_y u_int16 *uartRxWrPtr, *uartRxRdPtr;
#endif

__mem_y struct MMC mmc;

void IterateFilesCallback(register __b0 u_int16 *name) {
    register int i;
    /* Dump the whole FAT directory entry */
    for (i=0;i<32/2;i++) {
        putword(*name++);
    }
}

void IdleHook(void);
auto void MyMain(register s_int16 __a1 fullReset) {
#ifdef LOOP_FILES
  USEX(SCI_AICTRL3) = CTRL3_LOOP_SONG;
#endif
    /* Install new idle hook handler */
    WriteIMem((u_int16)IdleHook, 0x28000000UL | ((u_int32)(u_int16)UserHook<<6));

    /* Make sure we have the right upper ROM visible. */
    USEX(VS1053_IROM4) &= ~(IROM4_ENABLE);
    /* For MMC/SD handling the SCI_NEWMODE must be set, and also
       the relevant GPIO pins configured correctly. */
    USEX(SCI_MODE) = (USEX(SCI_MODE) & ~(1<<SCIMB_OUT_OF_WAV)) |
	(1<<SCIMB_SDI_NEWMODE) | (1<<SCIMB_LINE)
#ifdef ENABLE_LAYER12
	| (1<<SCIMB_ALLOW_LAYER12)
#endif
	;
    USEX(GPIO_ODATA) = SPI_xCS|SPI_CLK|SPI_xCS2|SD_POWER_ENABLE;
    USEX(GPIO_DDR)   = SPI_xCS|SPI_CLK|SPI_xCS2|SD_POWER_ENABLE
    #if defined(ENABLE_I2S)
	/* Enable I2S pins */
	| 0xf0;
      USEX(I2S_CONTROL) = 0x0c
    #endif
	;
    /* clear mp4ASC, seems to be needed after FLAC in vs1063,clear here also.*/
    memset((void *)0x1f00, 0, 64); /*Note: different addr for vs1053 and 63*/
    USEX(SCI_HDAT1) = 0; /* clear so FLAC is not indicated. */
    /* no files yet */
    USEX(SCI_AICTRL1) = 0;
    memset(&spix, 0, sizeof(spix));

#ifdef UART_BUFFERED
    UartFill(); /* Pull in the interrupt handler and other functions. */
    /* The buffer pointers are initialized when the program is loaded,
       when we restart by calling MyMain() again, they are kept, so no
       already received bytes will be missed because of that. Bytes may
       still be missed due to clock change during initialization or
       because interrupts are disabled for too long during init. */
//  uartRxWrPtr = uartRxRdPtr = uartRxBuffer;
    USEX(INT_ENABLE) = (1<<INT_EN_RX);
//  putstrp("\pStart\n");
#endif

    /* InitHardware() sets default UART speed to 9600bps,
       configures clock/PLL according to SCI_CLOCKF,
       initializes stream and audio buffer pointers,
       sets default samplerate (8000Hz),
       clears HDAT0,HDAT1,DECODE_TIME,AUDATA,
       and sets the cosmetic chip ID in parametric_x.chipID .
    */
    InitHardware(); /* no longer clears memory in vs1053 so preserves consts */
    if (fullReset) {
	register __mem_y s_int16 *p = audio_buffer;
	register int i;
	memsetY(audio_buffer, 24000, 2*800);
	for (i=0;i<400;i++) {
	    p[0] = -24000;
	    p[1] = -24000;
	    p += 4;
	}
	//audioPtr.wr = p;
	audio_wr_pointer = p;
	/*analog power off and analog driver powerdown */
	USEX(SCI_STATUS) |= (1<<SCIST_APDOWN1)|(1<<SCIST_APDOWN2);
    } else {
	/* If not powerup reset, re-enable analog immediately. */
	USEX(SCI_STATUS) &= ~(1<<SCIST_APDOWN2);
	ui.KeyTime = -32000;
    }

  #ifndef USE_DEBUG
    /* Enable UART RX interrupt to be able to jump to emulator.
       Allows reflashing without MMC/SD inserted. */
    USEX(INT_ENABLE) = (1<<INT_EN_RX);
  #endif



    #if defined(ENABLE_HIGHREF)
      /* Calculates ui.Timer and ui.Strobe, keeps settings 1.65V reference.*/
      applAddr = ApplAddrButRef;
    #else
      /* Calculates ui.Timer and ui.Strobe. */
      applAddr = ApplAddr;
    #endif

    /* Allow DREQ and enable interrupts, VERY IMPORTANT! */
    //USEX(INT_ENABLE) = 0;
    USEX(INT_GLOB_ENA) = 0;
    USEX(INT_GLOB_ENA) = 0;
    //USEX(INT_GLOB_ENA) = 0;

    #ifdef SAVE_POSITION
      /* Clear the current song number so it will reset between cards. */
      if (USEX(SCI_AICTRL0))
          SaveWord(28/*AICTRL0*/, 0);
    #endif

    USEX(INT_ENABLE) = ENABLE_SCI_DAC_RX;


 cardchanged:
    memsetY(&mmc, 0, sizeof(mmc));
    /* Initialize MMC/SD card, required for both player and recorder. */
    InitializeMmc(50);
    if (mmc.state != mmcOk || mmc.errors)
	goto cardchanged;

    putstrp("\pcard ok\n");

    // Init File System (FAT)
    memset(stream_buffer, 0, 512/2);
    if (InitFileSystem() != 0) {    /* Detects cards without partition table */
#ifdef UART_BUFFERED
	putstrp("\pNo FAT\n");
#endif
	goto cardchanged;//MyReset();
    }

    if ((USEX(SCI_AICTRL3) & CTRL3_NO_NUMFILES)) {
	/* Startup is faster if we don't need to find number of files. */
	USEX(SCI_AICTRL1) = 0x7fff;
    } else {
	/* determine number of playable files */
	USEX(SCI_AICTRL1) = OpenFile(0xffffU);
    }
#if 0
    /* In hex format */
    putstrp("\pfat ");
    puthex(fatInfo.totSize>>16);
    puthex(fatInfo.totSize);
    putstrp("\p\nfiles ");
    puthex(USEX(SCI_AICTRL1));
    putch('\n');
#else
    /* In decimal format */
    putstrp("\pfat ");
    putdec(fatInfo.totSize);
    putstrp("\p\nfiles ");
    putdec(USEX(SCI_AICTRL1));
    putch('\n');
#endif

 fileloop:
#ifdef UART_BUFFERED
    if (fileMode) {
	static u_int16 buffer[80];
	register u_int16 *bf = buffer;

	//USEX(SCI_AICTRL0) = -1;
	goto prompt;
	while (1) {
	    if (UartFill()) {
		int cmd = UartGetByte();
		*bf = 0;
//putch(cmd);
		if (cmd == '\n' || bf == &buffer[79]) {
		    /* Build a 8.3-character filename */
		    fileName[0] = (buffer[1]<<8) | buffer[2];
		    fileName[1] = (buffer[3]<<8) | buffer[4];
		    fileName[2] = (buffer[5]<<8) | buffer[6];
		    fileName[3] = (buffer[7]<<8) | buffer[8];
		    fileName[4] = (buffer[9]<<8) | buffer[10];
		    fileName[5] = (buffer[11]<<8);

#if 1
		    /* Whenever a command is entered,
		       poll MMC/SD present by giving it a command.
		       But only when idle, i.e. mmcOk. */
		    if (mmc.state == mmcOk && mmc.errors == 0 &&
			MmcCommand(MMC_SET_BLOCKLEN|0x40, 512) != 0) {
			mmc.errors++;
			putstrp("\pcard removed\n");
			goto cardchanged;
		    }
#endif
		    switch (buffer[0]) {
#ifdef USE_PRINTABLE_OUTPUT
		    case '?':
		      putstrp("\pL - list files\nPFILENAMEOGG - play by name\np<num> - play by number\nc - continuous play mode\n");
		      break;
#endif
		    case 'c':
			/* continuous play mode */
			fileMode = 0;
			goto playloop;

		    case 'L':
			/* List files - calls IterateFilesCallback() */
			USEX(SCI_AICTRL3) |= CTRL3_ITERATE;
			OpenFile(0x7fff);
			USEX(SCI_AICTRL3) &= ~CTRL3_ITERATE; /*turn off!*/
			break;

		    case 'P':  /* 'P'lay by name */
			/* already put the name into the fileName variable */
			USEX(SCI_AICTRL3) |= CTRL3_BY_NAME;
			OpenFile(0x7fff); /*OpenFile writes AICTRL0*/
			USEX(SCI_AICTRL3) &= ~CTRL3_BY_NAME;
			goto checkvalidfile;
		    case 'p': /* 'p'lay by number */
			USEX(SCI_AICTRL0) = atou((void *)&buffer[1]);
		    checkvalidfile:
			if (USEX(SCI_AICTRL0) >= USEX(SCI_AICTRL1)) {
			    putstrp("\pnot found ");
			    puthex(USEX(SCI_AICTRL0));
			    putch(' ');
			    putstrpy(fileName);
			    putch('\n');
			    break;
			}
			goto playloop;
		    }
		    bf = buffer;
		prompt:
		    putword(('>'<<8)|' ');
		} else {
		    *bf++ = cmd;
		}
	    }
	    /* If OpenFile found read errors. */
	    if (mmc.state != mmcOk || mmc.errors) {
		goto cardchanged;
	    }
	}
    }
 playloop:
#endif /*UART_BUFFERED*/
    

    if ((USEX(SCI_AICTRL3) & CTRL3_RANDOM_PLAY)) {
#ifdef SHUFFLE_PLAY /*shuffle 23 words*/
	USEX(SCI_AICTRL0) = Shuffle(USEX(SCI_AICTRL1), USEX(SCI_AICTRL0));
#else
	/* random play (not shuffle!) */
	USEX(SCI_AICTRL0) = (myrand() % USEX(SCI_AICTRL1));
#endif
    }

 reopen:
    /* Wrap from last file to first file */
    if (USEX(SCI_AICTRL0) >= USEX(SCI_AICTRL1)) {
	USEX(SCI_AICTRL0) -= USEX(SCI_AICTRL1);
    }
    /* Open the file to play. The file number is in AICTRL0. */
    if (OpenFile(USEX(SCI_AICTRL0) &= 0x7fffU /*max 32768 files*/) < 0) {
	PlayCurrentFile();
#ifdef UART_BUFFERED
	//putstrp("\pPlayCurrentFile returned\n");
#endif
	//MyReset();
    } else {
#ifdef UART_BUFFERED
	putstrp("\pfile not found\n");
#endif
	USEX(SCI_AICTRL0) = 0; /* file not found, jump to first file */
	//MyReset(); //Until we have uSD status check...
	//goto reopen;
	goto cardchanged;
    }
    if (mmc.state != mmcOk || mmc.errors)
	goto cardchanged;
    goto fileloop;
}
