#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>

#define STATUS_SIZE 16

#define RS232_SPEED 9600

int RS_InitComm(int comPort);
int RS_CloseComm(void);
int RS_SetCommSpeed(long speed);
int RS_SendData(char *data, int len);
int RS_ReceiveData(char *data, int len);
void RS_Wait(void);
void RS_Drain(void);

/***************************************************************************/
int RS_InitComm(int comPort);
int RS_CloseComm(void);
int RS_SetCommSpeed(long speed);
int RS_SendData(char *data, int len);
int RS_ReceiveData(char *data, int len);
void RS_Wait(void);
void RS_Drain(void);

/*

FILE: rs232.c - serial connection functions
DESCRIPTION: Serial communication for unix / DOS

*/
#define BAUDRATE B9600
#define DEF_BAUDRATE 9600

unsigned int baudRate=DEF_BAUDRATE;
volatile int * volatile breakPtr = NULL;

void RS_SetBreakIntVar(volatile int *breakVar) {
    breakPtr = breakVar;
}

#ifndef WIN32

#include <sys/types.h>
#include <termios.h>
#include <fcntl.h>

#include <stdio.h>
#include <string.h>
#include <unistd.h>

/* FreeBSD termios-based serial communication */

int newsfd;
struct termios oldtio;

void RS_Wait(void) {
    usleep(100000);
}

void RS_Drain(void) {
    tcdrain(newsfd);
}

int RS_InitComm(int comPort) {
    static char commDevice[80];
#if !defined(__linux__) && !defined(linux)
    sprintf(commDevice, "/dev/cuaa%d", comPort-1);
#else
    sprintf(commDevice, "/dev/ttyS%d", comPort-1);
#endif
    /* support ttyUSBxx */
    if (comPort >= 1000) {
	sprintf(commDevice, "/dev/ttyUSB%d", comPort - 1000);
    }
    newsfd = open(commDevice, O_RDWR | O_NOCTTY);
    if (newsfd <0) {
	perror(commDevice);
	return -1;
    }
    tcgetattr(newsfd,&oldtio); /* save current port settings */
    return RS_SetCommSpeed(baudRate);
}

void RS_SendBreak() {
    tcsendbreak(newsfd, 0); /* 0.25 .. 0.5 sec break */
}

int RS_SendData(char *data, int len) {
    if (write(newsfd, data, len) < 0)
	perror("Write error");
    return 0;
}

int RS_ReceiveData(char *data, int len) {
  int i = 0;

  while (len - i > 0) {
      int k = read(newsfd, data+i, len - i);

      //fprintf(stderr, "Read %d\n", k);
      if (k < 0) {
	  /* read error, restart read */
	//fprintf(stderr, "Read err, restart\n");
      } else {
	  i += k;
	  /* timeout, check breakPtr */
	  if (k == 0 && breakPtr) {
	      if (breakPtr && *breakPtr) {
		//fprintf(stderr, "timeout + break\n");
		  return -(i+1);
	      }
	  }
      }
  }
  return 0;
}

int RS_CloseComm(void) {
    /* restore old port settings */
    tcsetattr(newsfd,TCSANOW,&oldtio);
    /* close serial port */
    close(newsfd);
    return 0;
}

#if defined(__linux__) || defined(linux)
#include <signal.h>
#include <sys/resource.h>
#include <linux/serial.h>
#include <sys/ioctl.h>
#endif



int Set_DTR(void) {
    int nRet;
    int status;
    status = 0;
    nRet = ioctl(newsfd, TIOCMGET,&status);
    if (nRet < 0)
	return 0;
    status |= TIOCM_DTR;
    nRet = ioctl(newsfd, TIOCMSET, &status);
    if (nRet < 0)
	return 0;
    return 1;
}


int Clr_DTR(void) {
    int nRet;
    int status;
    status = 0;
    nRet = ioctl(newsfd, TIOCMGET,&status);
    if (nRet < 0)
	return 0;
    status &= ~TIOCM_DTR;
    nRet = ioctl(newsfd, TIOCMSET, &status);
    if (nRet < 0)
	return 0;
    return 1;
}


struct Speed {
  unsigned long symbol;
  int bps;
} speeds[] = {
  {B0      , 	  0},	/* hang up */
  {B50     ,      50},
  {B75     ,      75},
  {B110    ,     110},
  {B134    ,     134},
  {B150    ,     150},
  {B200    ,     200},
  {B300    ,     300},
  {B600    ,     600},
  {B1200   ,    1200},
  {B1800   ,    1800},
  {B2400   ,    2400},
  {B4800   ,    4800},
  {B9600   ,    9600},
  {B19200  ,   19200},
  {B38400  ,   38400},
  {B57600  ,   57600},
  {B115200 ,  115200},
  {B230400 ,  230400},
#ifdef B460800
  {B460800 ,  460800},
#endif
#ifdef B500000
  {B500000 ,  500000},
#endif
#ifdef B576000
  {B576000 ,  576000},
#endif
#ifdef B921600
  {B921600 ,  921600},
#endif
#ifdef B1000000
  {B1000000, 1000000},
#endif
#ifdef B1152000
  {B1152000, 1152000},
#endif
#ifdef B1500000
  {B1500000, 1500000},
#endif
#ifdef B2000000
  {B2000000, 2000000},
#endif
#ifdef B2500000
  {B2500000, 2500000},
#endif
#ifdef B3000000
  {B3000000, 3000000},
#endif
#ifdef B3500000
  {B3500000, 3500000},
#endif
#ifdef B4000000
  {B4000000, 4000000},
#endif
};

/*

FUNCTION: SetCommSpeed()
DESCRIPTION: Sets communications speed
INPUTS: speed - desired speed in bps
RESULT: 0 if there were no errors, -1 otherwise
SEE ALSO:

*/
int RS_SetCommSpeed(long speed) {
    struct termios speedtio;
    unsigned long speedSymbol;
    int i = 0;
#if defined(__linux__) || defined(linux)
    int customSpeed = 0;
#endif

    while (i < sizeof(speeds)/sizeof(speeds[0]) && speed != speeds[i].bps)
	i++;

    if (i >= sizeof(speeds)/sizeof(speeds[0])) {
#if defined(__linux__) || defined(linux)
	customSpeed = 1;
	speedSymbol = B38400;
#else
	speedSymbol = speed; /*FreeBSD takes a value instead of bit mask!*/
#endif
    } else {
	speedSymbol = speeds[i].symbol;
    }

    /* set new port settings for canonical input processing */
    memset(&speedtio, 0, sizeof(speedtio));
    tcgetattr(newsfd,&speedtio); /* save current port settings */
    speedtio.c_cflag = CS8 | CLOCAL | CREAD ;
    speedtio.c_iflag = IGNPAR;
    speedtio.c_oflag = 0;
    speedtio.c_lflag = 0;

    cfmakeraw(&speedtio);

    speedtio.c_cc[VMIN] = 0;
    speedtio.c_cc[VTIME] = 1;//30;//15; /* in 0.1sec granularity, VMIN=0 */

#if defined(__linux__) || defined(linux)
    if (customSpeed) {
	struct serial_struct ss;
	int closestSpeed;

	ioctl(newsfd, TIOCGSERIAL, &ss);
	ss.flags = (ss.flags & ~ASYNC_SPD_MASK) | ASYNC_SPD_CUST;
	ss.custom_divisor = (ss.baud_base + (speed / 2)) / speed;
	if (ss.custom_divisor == 0)
	    ss.custom_divisor = 1;
	closestSpeed = ss.baud_base / ss.custom_divisor;

	if (closestSpeed < speed * 98 / 100 ||
	    closestSpeed > speed * 102 / 100) {
	    fprintf(stderr, "Cannot set serial port speed to %d. "
		    "Closest possible is %d\n",
		    (int)speed, closestSpeed);
	}
	ioctl(newsfd, TIOCSSERIAL, &ss);
    }
#endif /*defined(__linux__) || defined(linux)*/

    cfsetispeed(&speedtio, speedSymbol);
    cfsetospeed(&speedtio, speedSymbol);
    if (tcsetattr(newsfd, TCSADRAIN, &speedtio)==-1) {
	printf("Serial port input speed (%ld) setting failed, errno: %d\n",
	       speed, errno);
	return -1;
    }
//   Set_DTR();
    Clr_DTR();
    return 0;
}

#else

/* See http://msdn.microsoft.com/library/default.asp?url=/library/en-us/devio/base/about_communications_resources.asp */
#include <windows.h>

/* module variables*/
HANDLE       SerialHandle;
DCB          Control;	      /* device control block */
COMMTIMEOUTS TimeOuts;

int RS_InitComm(int comPort)  {
    static char portName[80];
    if (comPort > 9) {
	sprintf(portName, "\\\\.\\COM%d", comPort);
    } else {
	sprintf(portName, "COM%d", comPort);
    }
    SerialHandle = CreateFile(portName,
			      GENERIC_READ|GENERIC_WRITE,
			      0,                  /* not shared */
			      NULL,		 /* no security attributes*/
			      OPEN_EXISTING,
			      FILE_ATTRIBUTE_NORMAL|FILE_FLAG_NO_BUFFERING|
			      FILE_FLAG_WRITE_THROUGH,
			      NULL);
  
    if (SerialHandle == INVALID_HANDLE_VALUE) {
	fprintf(stderr, "Couldn't open serial port!\n");
	return -1;
    }
    if (!BuildCommDCB("baud=1200 parity=N data=8 stop=1", &Control)) {
	fprintf(stderr, "Couldn't build control block!\n");
	return -1;
    }
    Control.DCBlength = sizeof(DCB);
    Control.BaudRate = baudRate;
    Control.fBinary = TRUE;
    Control.fParity = FALSE;
    Control.fOutxCtsFlow = FALSE;
    Control.fOutxDsrFlow = FALSE;
    Control.fDtrControl = DTR_CONTROL_DISABLE;
    Control.fDsrSensitivity = FALSE;
    Control.fTXContinueOnXoff = FALSE;
    Control.fOutX = FALSE;
    Control.fInX = FALSE;
    Control.fErrorChar = FALSE;
    Control.fNull = FALSE;
    Control.fRtsControl = RTS_CONTROL_DISABLE;
    Control.fAbortOnError = TRUE;
    /* set user defined values */
    if (!SetCommState(SerialHandle, &Control)) {
	fprintf(stderr, "Couldn't set control state!\n");
	return -1;
    }

    TimeOuts.ReadIntervalTimeout    = 0; /* max. time between two bytes in ms*/
    TimeOuts.ReadTotalTimeoutMultiplier = 0; /*1second/byte allowed*/
    TimeOuts.ReadTotalTimeoutConstant   = 4000; /*ms overhead in the start of tx*/
    TimeOuts.WriteTotalTimeoutMultiplier= 0; /*ms/write allowed */
    TimeOuts.WriteTotalTimeoutConstant  = 0; /*ms overhead in the start of tx*/

    if (!SetCommTimeouts(SerialHandle, &TimeOuts)) {
	fprintf(stderr, "Couldn't set timeout values!\n");
	return -1;
    }
    /* clear input buffer */
    PurgeComm(SerialHandle, PURGE_RXABORT | PURGE_RXCLEAR);
    return 0;
}

int RS_ReceiveData(char *data, int len) {
    int i = 0;

    while (len - i > 0) {
	DWORD read = 0;

	ReadFile(SerialHandle, (BYTE *)data+i, len-i, &read, NULL);
	if (read < 0) {
	    /* read error */
	} else {
	    i += read;
	    /* timeout, check breakPtr */
	    if (read == 0 && breakPtr) {
		if (breakPtr && *breakPtr)
		    return -(i+1);
	    }
	}
    }
    return 0;
}

void RS_SendBreak() {
    /*tcsendbreak(newsfd, 0);*/ /* 0.25 .. 0.5 sec break */
    RS_Drain();
    SetCommBreak(SerialHandle); /*EscapeCommFunction(SerialHandle, SETBREAK);*/
    Sleep(500);
    ClearCommBreak(SerialHandle); /*EscapeCommFunction(SerialHandle, CLRBREAK);*/
}

int RS_SendData(char *data, int len) {
    DWORD written;
  
    WriteFile(SerialHandle, (BYTE *)data, len, &written, NULL);
    if (written != len) {
	fprintf(stderr, "Write byte failed!\n");
	return -1;
    }
	return 0;
}

int RS_CloseComm(void) {
    PurgeComm(SerialHandle, PURGE_RXABORT | PURGE_RXCLEAR);
    CloseHandle(SerialHandle);
    return 0; 
} 
 
int RS_SetCommSpeed(long speed) {
    if (!GetCommState(SerialHandle, &Control)) {
	fprintf(stderr, "Couldn't get control state!\n");
	return -1;
    }
    Control.BaudRate = speed;
    if (!SetCommState(SerialHandle, &Control)) {
	fprintf(stderr, "Couldn't set control state!\n");
	return -1;
    }
    return 0;
}

void RS_Drain(void) {
    FlushFileBuffers(SerialHandle);
}

void RS_Wait(void) {
    Sleep(300);
}
#endif
/***************************************************************************/



#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <termios.h>
#include <signal.h>

#define TIMEOUT 0 /* no timeout */
struct termios org, new;
 
void rememberterminal()
{
  tcgetattr(0, &org);
}
 
void initterminal(int timeout)
{
  tcgetattr(0, &new);
  new.c_lflag &= ~ECHO;
  new.c_lflag &= ~ICANON; /* ei-kanoninen input-moodi */
  //  cfmakeraw(&new);

  /* seuraavat arvot maarittelevat luettavien merkkien minimimaaran ja */
  /* niiden lukemiseen maksimissaan kaytettavan ajan kymmenesosasekunteina */
  /* tarkempaa selvitysta loytyy komennolla 'man termio' */
  new.c_cc[VMIN] = 1;
  new.c_cc[VTIME] = timeout; /* TIMEOUT*0.1s */

#ifdef VDSUSP /*not for LINUX*/
  new.c_cc[VDSUSP] = 0;
#endif

  tcsetattr(0, TCSANOW, &new);
}
 
void backterminal()
{
  tcsetattr(0, TCSANOW, &org);
}

void SigCont()
{
    initterminal(TIMEOUT);
    signal(SIGCONT, SigCont);
    return;
}




int main(int argc, char **argv) {
  time_t lastOpT;
  int i, c;
  int blockSize, blocks, usedBlocks;
  int totErr = 0;
  int mode = 0;
  FILE *sendFile = 0;
  int breakVar = 1, port = 1;

  if (strcasestr(argv[0], "usb")) {
    port = 1000;
  }
  if (RS_InitComm(port))
    exit(-1);
  RS_SetCommSpeed(9600);
  RS_SetBreakIntVar(&breakVar);

  if (argc > 1) {
      sendFile = fopen(argv[1], "rb");
  }

  printf("Interactive mode, port %d\n", port);

  fcntl(fcntl(STDIN_FILENO,  F_DUPFD, 0), F_SETFL, O_NONBLOCK);

  rememberterminal();
  signal(SIGCONT, SigCont);
  initterminal(TIMEOUT);

  while(1) {
      unsigned char d;
      int c;

      if (sendFile) {
	  char line[80], *t;
	  if (fgets(line, 80-1, sendFile)) {
	      if (line[0] != '#') {
		  c = strtol(line, &t, 0);
		  if (t && *t==',') {
		      static int waited = 0;
#if 1
		      printf("-> '%d' %02x\n", c, c);
#endif
		      d = c;
		      RS_SendData(&d,1);
		      if (c == 0xef && !waited) {
			  waited = 1;
			  sleep(1);
		      }
		  } else {
		      printf("IGNORE: %s", line);
		  }
	      }
	      while (RS_ReceiveData(&d,1) >= 0) {
		c = d;
		  printf("RCV %c %02x ", isprint(c) ? c : '.', c);
	      }

	  } else {
	      fclose(sendFile);
	      sendFile = NULL;
	  }
      } else if ((c = getchar()) >= 0) {
	  /*	printf("ch=0x%04x\n", c);*/
	  d = c;// & 127;
	  RS_SendData(&d,1);
#if 1
	  printf("-> '%d' %02x\n", d, d);
#endif
      } else if (RS_ReceiveData(&d,1) >= 0) {
	c = d;
	  if (argc > 1) {
	      printf("%c %02x ", isprint(c) ? c : '.', c);
	  } else {
	      if (isprint(c) || c == '\r' || c == '\n') {
		  putchar((c == '\r') ? '\n' : c);
	      } else {
#if 0
		  if (c & 128) {
		      printf("\033[5m%c\033[0m", ' ' + (c & 31));
		  } else {
		      printf("\033[7m%c\033[0m", ' ' + (c & 31));
		  }
#else
		  printf("\033[1m\\x%02x\033[0m", c);
#endif
	      }
	  }
	  fflush(stdout);
      } else {
	  usleep(20000);
      }
  }
    backterminal();
  return 0;
}
