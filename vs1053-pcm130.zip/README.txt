VS1053b PCM Mixer v1.2pre
======================

The PCM mixer allows a mono 8kHz, 12kHz, 16kHz, or 24kHz linear PCM stream
be played back during any audio format playback. This audio signal is
upsampled to at least 24kHz and played through the SDM side channel of
vs1053.

During startup AICTRL0 specifies the sample rate and AICTRL1 specifies
which GPIO pin(s) to use for flow control. The value is a mask, so write
0 to AICTRL1, if you don't want any GPIO pin used. Use 0x02 for GPIO1,
0x04 for GPIO2, 0x08 for GPIO3 etc.

Note: only 12.288MHz XTALI is supported.

The PCM data is sent through the SCI_AICTRL1 register, SCI_AICTRL0
tells how much space is in the PCM FIFO (you can send upto this many words).
Note that SCI multiple write (see vs1053 datasheet) can be used to
write multiple words with minimal overhead. During startup AICTRL0
specifies the sample rate.

SCI_AICTRL2 controls volume independently of the normal playback volume.
SCI_AICTRL2 value from 0 to 181 controls PCM volume in 0.5dB steps.
Note: only the low 8 bits of SCI_AICTRL2 control the volume.

Note: to prevent sigma-delta modulator overflow, SCI_VOL should be
at least 2dB (0x0404), and the sum of SCI_VOL and SCI_AICTRL2 attenuations
at least 6dB (12). If you have not set large enough attenuations,
the PCM Mixer adjusts the registers automatically to have at least these
values. To have absolutely safe scaling, have 6dB (0x0c0c) or more in
both SCI_VOL and SCI_AICTRL2.

The PCM mixer takes about 2.5MHz of processing power when in use.
Processing will be automatically disabled after a 0.125-second timeout
when samples are not being written to SCI_AICTRL1. The processing
is resumed when there are at least 64 samples in the PCM FIFO (1/4 full).

The PCM mixer works with VS1053b Patches Package. If you use the
VS1053b Patches package, load it first, then the VS1053 PCM Mixer
(PCM Mixer uses the application hook).

Perform the the normal system startup (including loading of the vs1053
patches package if you are using it), then load vs1053pcm.plg,
then write your samplerate 8000, 12000, 16000, or 24000 to AICTRL0,
you can also write the suitable volume settings to SCI_VOL and AICTRL2,
then write 0x0d00 to AIADDR to start the PCM Mixer.
- read AICTRL0: tells how many samples can be sent
- write AICTRL1 to send the samples
- write AICTRL2 to set volume attenuation for the PCM stream (only low byte)

The PCM Mixer will deactivate in a software reset, so load it again
and write 0x0d00 to AIADDR to restart.

Pseudo-code:
    s_int16 samples[32];

	s_int16 availSpace = Mp3ReadReg(SCI_AICTRL0);
	if (availSpace > 32) {
	   ReadSamples(samples, 32);
	   Mp3WriteRegMultiple(SCI_AICTRL1, samples, 32);
	}


CHANGES
- 20110427: Bug: used AICTRL1 instead of AICTRL0 to check for
	    16kHz and 12kHz rates. (fixed)
