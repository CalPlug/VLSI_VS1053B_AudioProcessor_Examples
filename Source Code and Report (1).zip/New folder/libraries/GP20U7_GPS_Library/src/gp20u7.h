#ifndef GP20U7_ARDUINO_H
#define GP20U7_ARDUINO_H

#include "devices/gps/gp20u7.h"

#endif